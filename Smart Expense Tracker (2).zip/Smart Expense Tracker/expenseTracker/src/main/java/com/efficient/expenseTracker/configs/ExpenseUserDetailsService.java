package com.efficient.expenseTracker.configs;

import com.efficient.expenseTracker.DTO.ErrorResponseDTO;
import com.efficient.expenseTracker.DTO.LoginRequestDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.Objects;


@Component
public class ExpenseUserDetailsService implements UserDetailsService{

    private final WebClient webClient;
    private static final Logger logger = LoggerFactory.getLogger(ExpenseUserDetailsService.class);

    @Autowired
    public ExpenseUserDetailsService(WebClient webClient){

        this.webClient=webClient;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        logger.info("The method is being called internally by authenticate method of authentication mgr");
        LoginRequestDTO loginRequestDTO = new LoginRequestDTO(username, null);
        Object result = webClient.post().uri("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(loginRequestDTO)
                .exchangeToMono(response -> {
                    if (response.statusCode().is2xxSuccessful()) {
                        return response.bodyToMono(new ParameterizedTypeReference<Map<String, String>>() {})
                                .cast(Object.class);
                    } else {
                        return response.bodyToMono(ErrorResponseDTO.class).cast(Object.class);
                    }
                }).timeout(Duration.ofSeconds(70))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in login {} ",e.getMessage());
                    return Mono.empty();
                }).block();
        if(result instanceof Map){
            return mapToUserDetails((Map<String, String>) result);
        }
        throw new UsernameNotFoundException("Bad credentials");
    }

    private UserDetails mapToUserDetails(Map<String, String> userDetailsMap) {
        logger.info("Inside mapToUserDetails method");
        String username =  userDetailsMap.get("username");
        String password = userDetailsMap.get("password");
        String role = userDetailsMap.get("role");

        GrantedAuthority authority = new SimpleGrantedAuthority(role);

        List<GrantedAuthority> authorities = List.of(authority);
        return new UserDetailsImpl(username, password, authorities);
    }
}
