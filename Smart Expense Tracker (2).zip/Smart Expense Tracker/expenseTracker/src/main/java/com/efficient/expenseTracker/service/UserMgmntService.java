package com.efficient.expenseTracker.service;

import com.efficient.expenseTracker.DTO.ErrorResponseDTO;
import com.efficient.expenseTracker.DTO.UserDTO;
import com.efficient.expenseTracker.exceptions.ActionNotAllowedException;
import com.efficient.expenseTracker.exceptions.AllExpenseTrackerExceptions;
import com.efficient.expenseTracker.exceptions.ResourceAlreadyExistsException;
import com.efficient.expenseTracker.exceptions.ResourceNotFoundException;
import com.efficient.expenseTracker.util.EligibilityAndValidationUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.List;

@Service
public class UserMgmntService implements IUserService{

    private final WebClient webClient;
    private final PasswordEncoder passwordEncoder;
    private final ErrorResponseDTO errorResponseDTO;

    @Autowired
    public UserMgmntService(WebClient webClient, PasswordEncoder passwordEncoder,ErrorResponseDTO errorResponseDTO){
        this.webClient=webClient;
        this.passwordEncoder = passwordEncoder;
        this.errorResponseDTO = errorResponseDTO;
    }

    private static final Logger logger = LoggerFactory.getLogger(UserMgmntService.class);

    @Override
    public List<UserDTO> getAllUsers(){
        logger.info("Inside the getAllUser() method in Service");
        return webClient.get()
                .uri("/api/User/db/fetch")
                .retrieve().bodyToFlux(UserDTO.class)
                .timeout(Duration.ofSeconds(70))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in getAllUsers {} ",e.getMessage());
                    return Mono.empty();
                }).collectList().block();
    }

    @Override
    public Object getUserById(int id){
        logger.info("Inside the getUserById() method in Service");
        Object result = webClient.get()
                .uri("/api/User/db/fetch/{id}", id)
                .exchangeToMono(response -> {
                    if (response.statusCode().is2xxSuccessful()) {
                        return response.bodyToMono(UserDTO.class);
                    } else {
                        return response.bodyToMono(ErrorResponseDTO.class);
                    }
                })
                .timeout(Duration.ofSeconds(70))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in getUserById {} ",e.getMessage());
                    return Mono.empty();
                }).block();
        if(result instanceof UserDTO){
            return result;
        }
        if(errorResponseDTO.getErrorCode().is5xxServerError()){
            logger.info("The data could not be fetched for the userId : {}", id);
            throw new AllExpenseTrackerExceptions((ErrorResponseDTO) result);
        }
        logger.info("The data could not be fetched for the userId : {}", id);
        throw new ResourceNotFoundException((ErrorResponseDTO) result);
    }

    @Override
    public Object addUser(UserDTO userDTO){
        logger.info("Printing the user to be added { \n {}",userDTO);
        logger.info("Inside addUser method of Service layer");
        userDTO.setPassword(passwordEncoder.encode(userDTO.getPassword()));
        Object result = webClient.post().uri("/api/User/db/add")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(userDTO)
                .exchangeToMono(response -> {
                    if (response.statusCode().is2xxSuccessful()) {
                        return response.bodyToMono(UserDTO.class);
                    } else {
                        return response.bodyToMono(ErrorResponseDTO.class);
                    }
                })
                .timeout(Duration.ofSeconds(70))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in addUser {} ",e.getMessage());
                    return Mono.empty();
                }).block();
        if(result instanceof UserDTO){
            return result;
        }
        if(errorResponseDTO.getErrorCode().is5xxServerError()){
            logger.info("The user could not be added");
            throw new AllExpenseTrackerExceptions((ErrorResponseDTO) result);
        }
        logger.info("The user could not be added");
        throw new ResourceAlreadyExistsException((ErrorResponseDTO) result);
    }

    @Override
    public Object updateUser(int id, UserDTO userDTO) {
        logger.info("Inside updateUser method of Service layer");
        userDTO.setPassword(passwordEncoder.encode(userDTO.getPassword()));
        String authenticatedUser = EligibilityAndValidationUtil.getAuthenticatedUser();
        if(!userDTO.getEmail().equals(authenticatedUser)){
           throw new SecurityException(String.format("User %s is not allowed to " +
                   "update any other user",authenticatedUser));
        }
        /// Prevent users from updating their role
        if (isRoleModified(userDTO)){
            throw new SecurityException("You are not allowed to update the role!");
        }
        Object result = webClient.put()
                .uri("/api/User/db/update/{id}", id)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(userDTO)
                .exchangeToMono(response -> {
                    if (response.statusCode().is2xxSuccessful()) {
                        return response.bodyToMono(UserDTO.class);
                    } else {
                        return response.bodyToMono(ErrorResponseDTO.class);
                    }
                })
                .timeout(Duration.ofSeconds(70))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in updateUser {} ",e.getMessage());
                    return Mono.empty();
                }).block();
        if(result instanceof UserDTO){
            return result;
        }
        logger.info("The user could not be updated");
        /// The resource not found exception will be caught within preauthorize condition itself if found.
        throw new AllExpenseTrackerExceptions((ErrorResponseDTO) result);
    }

    @Override
    public Object deleteUser(int id) {
        logger.info("Inside deleteUser in service layer");
        Object result = webClient.delete()
                .uri("/api/User/db/delete/{id}", id)
                .exchangeToMono(response -> {
                    if (response.statusCode().is2xxSuccessful()) {
                        return response.bodyToMono(String.class);
                    } else {
                        return response.bodyToMono(ErrorResponseDTO.class);
                    }
                })
                .timeout(Duration.ofSeconds(20))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in delete user {} ",e.getMessage());
                    return Mono.just("Error deleting user");
                }).block();
        if(result instanceof String){
            return result;
        }
        if(errorResponseDTO.getErrorCode().is5xxServerError()){
            logger.info("The user could not be deleted");
            throw new AllExpenseTrackerExceptions((ErrorResponseDTO) result);
        }
        logger.info("The user could not be deleted");
        throw new ResourceNotFoundException((ErrorResponseDTO) result);
    }

    /// This is used internally within PreAuthorize for RBAC
    @Override
    public Object getUserEmailById(int userId){
        logger.info("Inside the getUserEmailById() method in Service");
        Object result = webClient.get()
                .uri("/api/User/db/fetchEmail/{userId}", userId)
                .exchangeToMono(response -> {
                    if (response.statusCode().is2xxSuccessful()) {
                        return response.bodyToMono(String.class);
                    } else {
                        return response.bodyToMono(ErrorResponseDTO.class);
                    }
                }).timeout(Duration.ofSeconds(70))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in getUserEmailById {} ",e.getMessage());
                    return Mono.empty();
                }).block();
        logger.info("Reached here within the preAuthorize method");
        if(result instanceof String){
            logger.info("Inside the instanceOf check");
            if(!result.equals(EligibilityAndValidationUtil.getAuthenticatedUser())){
                throw new ActionNotAllowedException((String)result);
            }
            return result;
        }
        throw new ResourceNotFoundException((ErrorResponseDTO) result);
    }
    private boolean isRoleModified(UserDTO userDTO){

        String role = EligibilityAndValidationUtil.getAuthenticatedUserRole();

        return !role.equals(userDTO.getRole());
    }
}
