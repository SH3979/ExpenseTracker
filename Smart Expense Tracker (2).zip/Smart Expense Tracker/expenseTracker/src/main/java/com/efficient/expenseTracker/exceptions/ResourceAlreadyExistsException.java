package com.efficient.expenseTracker.exceptions;

import com.efficient.expenseTracker.DTO.ErrorResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;

public class ResourceAlreadyExistsException extends RuntimeException{

    @Autowired
    private final ErrorResponseDTO errorResponseDTO;

    public ResourceAlreadyExistsException(ErrorResponseDTO errorResponseDTO){
        this.errorResponseDTO = errorResponseDTO;
    }

    public ErrorResponseDTO getErrorResponse(){
        return this.errorResponseDTO;
    }
}