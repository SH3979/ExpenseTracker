package com.efficient.expenseTracker.Scheduler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.concurrent.CompletableFuture;

@Component
public class ExpenseTrackerErrorMonitor {

    @Value("${expenseTracker.logFile}")
    private String logFilePath;

    private static final Logger logger = LoggerFactory.getLogger(ExpenseTrackerErrorMonitor.class);
    private long lastFileSize = 0;

    private final JavaMailSender javaMailSender;

    @Autowired
    public ExpenseTrackerErrorMonitor(JavaMailSender javaMailSender) {
        this.javaMailSender = javaMailSender;
    }

    @Scheduled(fixedDelay = 60000) // every 60 seconds
    public void checkLogFileForErrors() throws IOException {

        File logFile = new File(logFilePath);

        if (!logFile.exists()) {
            logger.warn("Log file not found: {}", logFilePath);
            return;
        }

        StringBuilder newLogs = new StringBuilder();

        try(RandomAccessFile file = new RandomAccessFile(logFile, "r")) {
            file.seek(lastFileSize);
            String line;

            while ((line = file.readLine()) != null) {
                newLogs.append(line).append("\n");
            }
            lastFileSize = file.length();
        }

        if (!newLogs.isEmpty()) {
            CompletableFuture<Void> result = sendErrorMail(newLogs.toString());

            result.exceptionally(ex ->
            {
                logger.error("Exception occurred while sending async email: ", ex);
                return null;
            });
        }
    }

    @Async
    private CompletableFuture<Void> sendErrorMail(String body) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo("expensetrackererrors@gmail.com");
            message.setSubject("New Error in Expense Tracker");
            message.setText(body);
            javaMailSender.send(message);
            logger.info("Sent error log email successfully.");
        } catch (Exception ex) {
            logger.error("Failed to send email: {}" , ex.getMessage());
            return CompletableFuture.failedFuture(ex);
        }
        return CompletableFuture.completedFuture(null);
    }
}
