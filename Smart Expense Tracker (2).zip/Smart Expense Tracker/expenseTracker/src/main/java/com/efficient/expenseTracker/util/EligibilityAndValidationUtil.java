package com.efficient.expenseTracker.util;

import com.efficient.expenseTracker.exceptions.RoleAccessNotAllowedException;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
import org.apache.coyote.BadRequestException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.util.Set;

@Component
public class EligibilityAndValidationUtil {

    public static Authentication getAuthenticationObj(){
        return SecurityContextHolder.getContext().getAuthentication();
    }
    public static String getAuthenticatedUser(){
        return getAuthenticationObj().getName();
    }

    public static String getAuthenticatedUserRole(){
        return SecurityContextHolder.getContext().getAuthentication()
                .getAuthorities().stream().toList().getFirst().toString();
    }

    /// Not static since called in preAuthorize conditions
    public boolean isNotUser(){
        if(getAuthenticatedUserRole().equals("USER")){
            throw new RoleAccessNotAllowedException("Only admins are allowed to access this functionality");
        }
        return true;
    }

    /// Not static since called in preAuthorize conditions

    public boolean isNotAdmin(){
        if(getAuthenticatedUserRole().equals("ADMIN")){
            throw new RoleAccessNotAllowedException("Only users are allowed to access this functionality");
        }
        return true;
    }

    /// Explicitly calling validation in order to ensure failing fast of the security before validation
    public static void validate(Object dto) throws BadRequestException {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        Set<ConstraintViolation<Object>> violations = validator.validate(dto);
        if (!violations.isEmpty()) {
            throw new BadRequestException(violations.iterator().next().getMessage());
        }
    }

}
