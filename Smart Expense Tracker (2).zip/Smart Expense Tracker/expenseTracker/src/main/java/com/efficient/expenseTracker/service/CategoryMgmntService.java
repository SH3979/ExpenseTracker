package com.efficient.expenseTracker.service;

import com.efficient.expenseTracker.DTO.CategoryDTO;
import com.efficient.expenseTracker.DTO.ErrorResponseDTO;
import com.efficient.expenseTracker.DTO.ExpenseDTO;
import com.efficient.expenseTracker.DTO.UserDTO;
import com.efficient.expenseTracker.exceptions.AllExpenseTrackerExceptions;
import com.efficient.expenseTracker.exceptions.ResourceAlreadyExistsException;
import com.efficient.expenseTracker.exceptions.ResourceNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.List;

@Service
public class CategoryMgmntService implements ICategoryService{

    private final WebClient webClient;
    private ErrorResponseDTO errorResponseDTO;

    @Autowired
    public CategoryMgmntService(WebClient webClient, ErrorResponseDTO errorResponseDTO){

        this.webClient=webClient;
        this.errorResponseDTO=errorResponseDTO;
    }

    private static final Logger logger = LoggerFactory.getLogger(CategoryMgmntService.class);

    @Override
    public List<CategoryDTO> getAllCategories(){
        logger.info("Inside the getAllCategories() method in Service");
        return webClient.get()
                .uri("/api/categories/db/fetch")
                .retrieve().bodyToFlux(CategoryDTO.class)
                .timeout(Duration.ofSeconds(20))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in getAllCategories {} ",e.getMessage());
                    return Mono.empty();
                }).collectList().block();
    }

    @Override
    public Object getCategoryById(int id){
        logger.info("Inside the getCategoryById() method in Service");
        Object result = webClient.get()
                .uri("/api/categories/db/fetch/{id}", id)
                .exchangeToMono(response -> {
                    if (response.statusCode().is2xxSuccessful()) {
                        return response.bodyToMono(CategoryDTO.class);
                    } else {
                        return response.bodyToMono(ErrorResponseDTO.class);
                    }
                })
                .timeout(Duration.ofSeconds(70))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in getCategoryById {} ",e.getMessage());
                    return Mono.empty();
                }).block();
        if(result instanceof CategoryDTO){
            return result;
        }
        errorResponseDTO = (ErrorResponseDTO) result;
        if(errorResponseDTO.getErrorCode().is5xxServerError()){
            logger.info("The category could not be fetched for the categoryId : {}", id);
            throw new AllExpenseTrackerExceptions((ErrorResponseDTO) result);
        }
        logger.info("The category could not be fetched for the categoryId : {}", id);
        throw new ResourceNotFoundException(errorResponseDTO);
    }

    @Override
    public Object addCategory(CategoryDTO categoryDTO){
        logger.info("Inside addCategory method of Service layer");
        Object result = webClient.post().uri("/api/categories/db/add")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(categoryDTO)
                .exchangeToMono(response -> {
                    if (response.statusCode().is2xxSuccessful()) {
                        return response.bodyToMono(CategoryDTO.class);
                    } else {
                        return response.bodyToMono(ErrorResponseDTO.class);
                    }
                })
                .timeout(Duration.ofSeconds(70))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in addCategory {} ",e.getMessage());
                    return Mono.empty();
                }).block();
        if(result instanceof CategoryDTO){
            return result;
        }
        errorResponseDTO = (ErrorResponseDTO) result;
        if(errorResponseDTO.getErrorCode().is5xxServerError()){
            logger.info("The category could not be added");
            throw new AllExpenseTrackerExceptions((ErrorResponseDTO) result);
        }
        logger.info("The category could not be added");
        throw new ResourceAlreadyExistsException(errorResponseDTO);
    }

    @Override
    public Object updateCategory(int id, CategoryDTO categoryDTO) {
        logger.info("Inside updateCategory method of Service layer");
        Object result = webClient.put()
                .uri("/api/categories/db/update/{id}", id)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(categoryDTO)
                .exchangeToMono(response -> {
                    if (response.statusCode().is2xxSuccessful()) {
                        return response.bodyToMono(CategoryDTO.class);
                    } else {
                        return response.bodyToMono(ErrorResponseDTO.class);
                    }
                })
                .timeout(Duration.ofSeconds(70))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in updateCategory {} ",e.getMessage());
                    return Mono.empty();
                }).block();
        if(result instanceof CategoryDTO){
            return result;
        }
        errorResponseDTO = (ErrorResponseDTO) result;
        if(errorResponseDTO.getErrorCode().is5xxServerError()){
            logger.info("The category could not be updated");
            throw new AllExpenseTrackerExceptions((ErrorResponseDTO) result);
        }
        logger.info("The category could not be updated");
        throw new ResourceNotFoundException(errorResponseDTO);

    }

    @Override
    public Object deleteCategory(int id) {
        logger.info("Inside deleteCategory in service layer");
        Object result = webClient.delete()
                .uri("/api/categories/db/delete/{id}", id)
                .exchangeToMono(response -> {
                    if (response.statusCode().is2xxSuccessful()) {
                        return response.bodyToMono(String.class);
                    } else {
                        return response.bodyToMono(ErrorResponseDTO.class);
                    }
                })
                .timeout(Duration.ofSeconds(70))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in deleteCategory {} ",e.getMessage());
                    return Mono.empty();
                }).block();
        if(result instanceof String){
            return result;
        }
        errorResponseDTO = (ErrorResponseDTO) result;
        if(errorResponseDTO.getErrorCode().is5xxServerError()){
            logger.info("The category could not be deleted");
            throw new AllExpenseTrackerExceptions((ErrorResponseDTO) result);
        }
        logger.info("The category could not be deleted");
        throw new ResourceNotFoundException(errorResponseDTO);
    }

}
