package com.efficient.expenseTracker.DTO;

import com.efficient.expenseTracker.expenseAnnotation.ValidRequestStructure;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;

@ValidRequestStructure
public class ExpenseDTO {

    private int id;

    @DecimalMin(value = "1.00", message = "Amount must be at least 1.00")
    @Digits(integer = 10, fraction = 2, message = "Amount must be a valid decimal with up to 2 decimal places")
    @NotBlank(message = "Amount should not be null")
    private double amount;

    @NotBlank(message = "Description should not be null")
    private String description;

    @Email(message = "please enter a valid email address for username")
    @NotBlank(message = "Username should not be null")
    private String email;

    @NotBlank(message = "Category should not be null")
    private String category;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    @Override
    public String toString() {
        return "ExpenseDTO{" +
                "id=" + id +
                ", amount=" + amount +
                ", description='" + description + '\'' +
                ", email='" + email + '\'' +
                ", category='" + category + '\'' +
                '}';
    }
}
