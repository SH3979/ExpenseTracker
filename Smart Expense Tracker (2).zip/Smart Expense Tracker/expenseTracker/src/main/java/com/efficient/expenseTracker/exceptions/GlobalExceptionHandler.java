package com.efficient.expenseTracker.exceptions;

import com.efficient.expenseTracker.DTO.ErrorResponseDTO;
import org.apache.coyote.BadRequestException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import java.io.IOException;
import java.time.LocalDateTime;

@RestControllerAdvice
public class GlobalExceptionHandler{

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    private final ErrorResponseDTO errorResponseDTO;

    @Autowired
    public GlobalExceptionHandler(ErrorResponseDTO errorResponseDTO) {
        this.errorResponseDTO = errorResponseDTO;
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponseDTO> handleGlobalException(Exception exception,
               WebRequest webRequest) {
        logError(exception, webRequest);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(setErrorResponseData
                (HttpStatus.INTERNAL_SERVER_ERROR, webRequest, exception));
    }

    @ExceptionHandler(IOException.class)
    public ResponseEntity<ErrorResponseDTO> handleIOException(IOException exception,
                     WebRequest webRequest) {
        logError(exception, webRequest);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(setErrorResponseData
                (HttpStatus.INTERNAL_SERVER_ERROR, webRequest, exception));
    }

    @ExceptionHandler(BadRequestException.class)
    public ResponseEntity<ErrorResponseDTO> handleBadRequestException(BadRequestException
                    exception, WebRequest webRequest) {
        logError(exception, webRequest);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(setErrorResponseData
                (HttpStatus.BAD_REQUEST, webRequest, exception));
    }

    /// Handles exception thrown by authenticationProvider when password is incorrect
    @ExceptionHandler(BadCredentialsException.class)
    public ResponseEntity<ErrorResponseDTO> handleBadCredentialsException(BadCredentialsException exception,
                                                                          WebRequest webRequest) {
        logError(exception, webRequest);
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(setErrorResponseData(HttpStatus.UNAUTHORIZED,
                webRequest, exception));
    }

    /// Handles exception thrown by loadByUserName method when username is incorrect
    @ExceptionHandler(UsernameNotFoundException.class)
    public ResponseEntity<ErrorResponseDTO> handleUsernameNotFoundException(UsernameNotFoundException exception,
                                                                            WebRequest webRequest) {
        logError(exception, webRequest);
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(setErrorResponseData(HttpStatus.UNAUTHORIZED,
                webRequest, exception));
    }

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ErrorResponseDTO> handleResourceNotFoundException(ResourceNotFoundException exception,
                                                                            WebRequest webRequest) {
        logError(exception, webRequest);
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(exception.getErrorResponse());
    }

    @ExceptionHandler(ResourceAlreadyExistsException.class)
    public ResponseEntity<ErrorResponseDTO> handleResourceAlreadyExistsException(ResourceAlreadyExistsException exception,
                                                                            WebRequest webRequest) {
        logError(exception, webRequest);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(exception.getErrorResponse());
    }

    @ExceptionHandler(ActionNotAllowedException.class)
    public ResponseEntity<ErrorResponseDTO> handleActionNotAllowedException(ActionNotAllowedException exception,
                                                                                 WebRequest webRequest) {
        logError(exception, webRequest);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(setErrorResponseData(HttpStatus.BAD_REQUEST,
                webRequest, exception));
    }

    @ExceptionHandler(AllExpenseTrackerExceptions.class)
    public ResponseEntity<ErrorResponseDTO> handleActionNotAllowedException(AllExpenseTrackerExceptions exception,
                                                                            WebRequest webRequest) {
        logError(exception, webRequest);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(exception.getErrorResponse());
    }

    @ExceptionHandler(RoleAccessNotAllowedException.class)
    public ResponseEntity<ErrorResponseDTO> handleActionNotAllowedException(RoleAccessNotAllowedException exception,
                                                                            WebRequest webRequest) {
        logError(exception, webRequest);
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(setErrorResponseData(HttpStatus.UNAUTHORIZED,
                webRequest, exception));
    }

    private ErrorResponseDTO setErrorResponseData(HttpStatus responseStatus, WebRequest webRequest,
                                                  Exception exception){
        errorResponseDTO.setApiPath(webRequest.getDescription(false));
        errorResponseDTO.setErrorCode(responseStatus);
        errorResponseDTO.setErrorMessage(exception.getMessage());
        errorResponseDTO.setErrorTime(LocalDateTime.now());
        return errorResponseDTO;
    }

    private void logError(Exception exception, WebRequest webRequest){
        String msg = "Endpoint Path : "+webRequest.getDescription(false)+" Cause: "+exception.getMessage();
        logger.error(msg);
    }

}

