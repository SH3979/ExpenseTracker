package com.efficient.expenseTracker.DTO;
import com.efficient.expenseTracker.expenseAnnotation.ValidRequestStructure;
import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.util.List;

@ValidRequestStructure
public class UserDTO {

    /// auto generated
    private int id;

    @Email(message = "please enter a valid email address for username")
    @NotBlank(message = "Username should not be null")
    private String email;

    @Pattern(regexp = "^(ADMIN|USER)$", message = "role must be either ADMIN or USER")
    @NotBlank(message = "Role should not be null")
    private String role;

    /// This will be part of JSON only if it is not null
    /// which will never be the case since we are never reading the password
    /// value from the DB MS
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @Size(min = 8, max = 16, message = "password must be between 8 to 16 characters")
    @Pattern(regexp = "^(?=.*\\d)(?=.*[@$!%*#?&])[A-Za-z\\d@$!%*#?&]+$",
            message = "password must be alphanumeric with at least 1 special character and 1 digit")
    /// This will only work during serialization but not deserialization unless triggered manually
    @NotBlank(message = "password should not be null")
    private String password;

    private List<ExpenseDTO> expenses;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public List<ExpenseDTO> getExpenses() {
        return expenses;
    }

    public void setExpenses(List<ExpenseDTO> expenses) {
        this.expenses = expenses;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {

        this.password = password;

    }

    @Override
    public String toString() {
        return "UserDTO{" +
                "id=" + id +
                ", email='" + email + '\'' +
                ", role='" + role + '\'' +
                ", password='" + password + '\'' +
                ", expenses=" + expenses +
                '}';
    }
}
