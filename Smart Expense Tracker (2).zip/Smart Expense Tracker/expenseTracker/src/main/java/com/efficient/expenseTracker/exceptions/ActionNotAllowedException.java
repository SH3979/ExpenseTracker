package com.efficient.expenseTracker.exceptions;

public class ActionNotAllowedException extends RuntimeException{

    public ActionNotAllowedException(String username){
        super(String.format("Logged in user cannot access / modify any details of the other user: %s ", username));
    }
}
