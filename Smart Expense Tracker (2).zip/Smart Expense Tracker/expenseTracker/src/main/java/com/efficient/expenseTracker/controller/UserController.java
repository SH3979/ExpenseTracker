package com.efficient.expenseTracker.controller;

import com.efficient.expenseTracker.DTO.UserDTO;
import com.efficient.expenseTracker.service.IUserService;
import com.efficient.expenseTracker.util.EligibilityAndValidationUtil;
import org.apache.coyote.BadRequestException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/user")
public class UserController {

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);
    private final IUserService iUserService;

    @Autowired
    public UserController(IUserService iUserService){
        this.iUserService=iUserService;
    }

    /// Instead of checking simple hasAuthority(Admin), we check through custom method to
    /// avoid default non-descriptive access denied error and get a more descriptive one
    @PreAuthorize("@eligibilityAndValidationUtil.isNotUser()")
    @GetMapping("/fetch")
    public ResponseEntity<List<UserDTO>> getAllUser(){
        logger.info("Inside the getAllUsers() method in Controller");
        List<UserDTO> usersList = iUserService.getAllUsers();
        return ResponseEntity.ok(usersList);
    }

    @PreAuthorize("hasAuthority('ADMIN') or " +
            "@userMgmntService.getUserEmailById(#id) == authentication.principal.username")
    @GetMapping("/fetch/{id}")
    public ResponseEntity<UserDTO> getUserById(@PathVariable int id){
        logger.info("Inside the getUserById() method in Controller");
        Object userDTO = iUserService.getUserById(id);
        logger.info("User is fetched successfully {}",userDTO);
        return ResponseEntity.ok((UserDTO) userDTO);
    }

    @PreAuthorize("@eligibilityAndValidationUtil.isNotUser()")
    @PostMapping("/add")
    public ResponseEntity<UserDTO> addUser(@RequestBody UserDTO userDTO) throws BadRequestException {
        logger.info("Inside the addUser method in Controller");
        /// calling validation manually to maintain security -> validation order
        EligibilityAndValidationUtil.validate(userDTO);
        Object savedUser = iUserService.addUser(userDTO);
        logger.info("User added successfully");
        return ResponseEntity.ok((UserDTO) savedUser);
    }

    @PreAuthorize("@eligibilityAndValidationUtil.isNotAdmin() and " +
            "@userMgmntService.getUserEmailById(#id) == authentication.principal.username")
    @PutMapping("/update/{id}")
    public ResponseEntity<UserDTO> updateUser(@PathVariable int id, @RequestBody UserDTO userDTO)
            throws BadRequestException {
        logger.info("Inside the updateUser method in Controller");
        /// calling validation manually to maintain security -> validation order
        EligibilityAndValidationUtil.validate(userDTO);
        Object updatedUser = iUserService.updateUser(id, userDTO);
        logger.info("User is updated successfully {}",updatedUser);
        return ResponseEntity.ok((UserDTO) updatedUser);
    }

    @PreAuthorize("hasAuthority('ADMIN') or " +
            "@userMgmntService.getUserEmailById(#id) == authentication.principal.username")
    @DeleteMapping("/delete/{id}")
    public String deleteUser(@PathVariable int id){
        logger.info("Inside deleteUser() in Controller");
        Object result  = iUserService.deleteUser(id);
        logger.info("User is deleted successfully");
        return (String) result;
    }

    @GetMapping("/test")
    public ResponseEntity<?> testAuth() {
        Authentication auth = EligibilityAndValidationUtil.getAuthenticationObj();
        return ResponseEntity.ok(auth);
    }
}
