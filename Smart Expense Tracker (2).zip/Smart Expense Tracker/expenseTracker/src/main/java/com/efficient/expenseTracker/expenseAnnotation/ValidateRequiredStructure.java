package com.efficient.expenseTracker.expenseAnnotation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import java.lang.reflect.Field;

public class ValidateRequiredStructure implements ConstraintValidator<ValidRequestStructure, Object> {

    @Override
    public boolean isValid(Object dto, ConstraintValidatorContext context) {
        boolean isValid = true;
        context.disableDefaultConstraintViolation();

        try{
            for(Field field : dto.getClass().getDeclaredFields()){
                /// This is to be able to access the given field of the DTO class at runtime
                field.setAccessible(true);
                Object value = field.get(dto); /// this gives the value of the field that this dto holds
                if(!field.getName().equals("expenses")) {
                    if (value == null) {
                        isValid = false;
                        context.buildConstraintViolationWithTemplate(field.getName() + " is required")
                                .addPropertyNode(field.getName()).addConstraintViolation();
                    }
                }
            }

        }catch(IllegalAccessException e){
            isValid = false;
            return isValid;
        }
        return isValid;
    }
}
