package com.efficient.expenseTracker.controller;

import com.efficient.expenseTracker.DTO.ExpenseDTO;
import com.efficient.expenseTracker.service.IExpenseService;
import com.efficient.expenseTracker.util.EligibilityAndValidationUtil;
import org.apache.coyote.BadRequestException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/expenses")
public class ExpenseMgmntController {

    private static final Logger logger = LoggerFactory.getLogger(ExpenseMgmntController.class);
    private final IExpenseService iExpenseService;

    @Autowired
    public ExpenseMgmntController(IExpenseService iExpenseService){
        this.iExpenseService=iExpenseService;
    }

    @PreAuthorize("@eligibilityCheckUtil.isNotUser()")
    @GetMapping("/fetch")
    public ResponseEntity<List<ExpenseDTO>> getAllExpenses(){
        logger.info("Inside the getAllExpenses() method in Controller");
        return ResponseEntity.ok(iExpenseService.getAllExpenses());
    }

    @PreAuthorize("hasAuthority('ADMIN') or " +
            "@expenseMgmntService.getExpenseOwnerEmail(#id) == authentication.principal.username")
    @GetMapping("/fetch/{id}")
    public ResponseEntity<ExpenseDTO> getExpensesById(@PathVariable int id) {
        logger.info("Inside the getExpensesById() method in Controller");
        Object expenseDTO = iExpenseService.getExpensesById(id);
        logger.info("Expense is fetched successfully {}",expenseDTO);
        return ResponseEntity.ok((ExpenseDTO) expenseDTO);
    }

    @PreAuthorize("@eligibilityCheckUtil.isNotAdmin() and " +
            "@expenseMgmntService.getExpenseOwnerEmail(#id) == authentication.principal.username")
    @PostMapping("/add")
    public ResponseEntity<ExpenseDTO> addExpense(@RequestBody ExpenseDTO expenseDTO)
            throws BadRequestException {
        /// calling validation manually to maintain security -> validation order
        EligibilityAndValidationUtil.validate(expenseDTO);
        Object savedExpense = iExpenseService.addExpense(expenseDTO);
        logger.info("Expense is added successfully {}",savedExpense);
        return ResponseEntity.ok((ExpenseDTO) savedExpense);
    }

    @PreAuthorize("@eligibilityCheckUtil.isNotAdmin() and " +
            "@expenseMgmntService.getExpenseOwnerEmail(#id) == authentication.principal.username")
    @PutMapping("/update/{id}")
    public ResponseEntity<ExpenseDTO> updateExpense(@PathVariable int id, @RequestBody ExpenseDTO expenseDTO)
            throws BadRequestException {
        /// calling validation manually to maintain security -> validation order
        EligibilityAndValidationUtil.validate(expenseDTO);
        Object updatedExpense = iExpenseService.updateExpense(id, expenseDTO);
        logger.info("Expense is updated successfully {}",updatedExpense);
        return ResponseEntity.ok((ExpenseDTO) updatedExpense);
    }

    @PreAuthorize("@eligibilityCheckUtil.isNotAdmin() and " +
            "@expenseMgmntService.getExpenseOwnerEmail(#id) == authentication.principal.username")
    @DeleteMapping("/delete/{id}")
    public String deleteExpense(@PathVariable int id){
        logger.info("Inside deleteExpense() in Controller");
        Object result = iExpenseService.deleteExpense(id);
        logger.info("Expense is deleted successfully");
        return (String) result;
    }

}
