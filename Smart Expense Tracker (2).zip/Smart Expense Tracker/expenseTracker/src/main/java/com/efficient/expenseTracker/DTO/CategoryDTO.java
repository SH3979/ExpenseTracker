package com.efficient.expenseTracker.DTO;

import com.efficient.expenseTracker.expenseAnnotation.ValidRequestStructure;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

@ValidRequestStructure
public class CategoryDTO {

    private int id;

    @NotBlank(message = "Category should not be null")
    @Pattern(regexp = "^[A-Za-z]+$", message = "please enter a valid category name")
    private String expenseCategory;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getExpenseCategory() {
        return expenseCategory;
    }

    public void setExpenseCategory(String expenseCategory) {
        this.expenseCategory = expenseCategory;
    }

}
