package com.efficient.expenseTracker.exceptions;

public class RoleAccessNotAllowedException extends RuntimeException{

    public RoleAccessNotAllowedException(String message){
        super(message);
    }
}
