package com.efficient.expenseTracker.service;

import com.efficient.expenseTracker.DTO.ErrorResponseDTO;
import com.efficient.expenseTracker.DTO.ExpenseDTO;
import com.efficient.expenseTracker.exceptions.ActionNotAllowedException;
import com.efficient.expenseTracker.exceptions.AllExpenseTrackerExceptions;
import com.efficient.expenseTracker.exceptions.ResourceNotFoundException;
import com.efficient.expenseTracker.util.EligibilityAndValidationUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.List;

@Service
public class ExpenseMgmntService implements IExpenseService{

    private final WebClient webClient;
    private final ErrorResponseDTO errorResponseDTO;

    @Autowired
    public ExpenseMgmntService(WebClient webClient,ErrorResponseDTO errorResponseDTO){

        this.webClient=webClient;
        this.errorResponseDTO=errorResponseDTO;
    }

    private static final Logger logger = LoggerFactory.getLogger(ExpenseMgmntService.class);


    @Override
    public List<ExpenseDTO> getAllExpenses(){
        logger.info("Inside the getAllExpenses() method in Service");

        return webClient.get()
                .uri("/api/expenses/db/fetch")
                .retrieve().bodyToFlux(ExpenseDTO.class)
                .timeout(Duration.ofSeconds(70))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in getAllExpenses {} ",e.getMessage());
                    return Mono.empty();
                }).collectList().block();
    }

    @Override
    public Object getExpensesById(int id) {
        logger.info("Inside the getExpensesById() method in Service");
        Object result = webClient.get()
                .uri("/api/expenses/db/fetch/{id}", id)
                .exchangeToMono(response -> {
                    if (response.statusCode().is2xxSuccessful()) {
                        return response.bodyToMono(ExpenseDTO.class);
                    } else {
                        return response.bodyToMono(ErrorResponseDTO.class);
                    }
                })
                .timeout(Duration.ofSeconds(70))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in getExpensesById {} ",e.getMessage());
                    return Mono.empty();
                }).block();
        if(result instanceof ExpenseDTO){
            return result;
        }
        if(errorResponseDTO.getErrorCode().is5xxServerError()){
            logger.info("The expense could not be fetched for the expenseId : {}", id);
            throw new AllExpenseTrackerExceptions((ErrorResponseDTO) result);
        }
        logger.info("The expense could not be fetched for the expenseId : {}", id);
        throw new ResourceNotFoundException((ErrorResponseDTO) result);
    }

    @Override
    public Object addExpense(ExpenseDTO expenseDTO){
        logger.info("Inside addExpense method of Service layer");
        logger.info("Printing the response received from the expenseDTO: \n {}",expenseDTO);
        Object result =  webClient.post().uri("/api/expenses/db/add")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(expenseDTO)
                .exchangeToMono(response -> {
                    if (response.statusCode().is2xxSuccessful()) {
                        return response.bodyToMono(ExpenseDTO.class);
                    } else {
                        return response.bodyToMono(ErrorResponseDTO.class);
                    }
                })
                .timeout(Duration.ofSeconds(70))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in addExpense {} ",e.getMessage());
                    return Mono.empty();
                }).block();
        if(result instanceof ExpenseDTO){
            return result;
        }
        if(errorResponseDTO.getErrorCode().is5xxServerError()){
            logger.info("The expense could not be added for the user : {}", expenseDTO.getEmail());
            throw new AllExpenseTrackerExceptions((ErrorResponseDTO) result);
        }
        logger.info("The expense could not be added for the user : {}", expenseDTO.getEmail());
        throw new ResourceNotFoundException((ErrorResponseDTO) result);
    }

    @Override
    public Object updateExpense(int id, ExpenseDTO expenseDTO){
        logger.info("Inside updateExpense method of Service layer");
        String authenticatedUser = EligibilityAndValidationUtil.getAuthenticatedUser();
        if(!expenseDTO.getEmail().equals(authenticatedUser)){
            throw new SecurityException(String.format("User %s is not allowed to " +
                    "update expense of any other user",authenticatedUser));
        }
        Object result = webClient.put()
                .uri("/api/expenses/db/update/{id}", id)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(expenseDTO)
                .exchangeToMono(response -> {
                    if (response.statusCode().is2xxSuccessful()) {
                        return response.bodyToMono(ExpenseDTO.class);
                    } else {
                        return response.bodyToMono(ErrorResponseDTO.class);
                    }
                })
                .timeout(Duration.ofSeconds(70))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in updateExpense {} ",e.getMessage());
                    return Mono.empty();
                }).block();
        if(result instanceof ExpenseDTO){
            return result;
        }
        logger.info("The expense could not be updated");
        /// The resource not found exception will be caught within preauthorize condition itself if found.
        throw new AllExpenseTrackerExceptions((ErrorResponseDTO) result);
    }

    @Override
    public Object deleteExpense(int id){
        logger.info("Inside deleteExpense in service layer");
        Object result = webClient.delete()
                .uri("/api/expenses/db/delete/{id}", id)
                .exchangeToMono(response -> {
                    if (response.statusCode().is2xxSuccessful()) {
                        return response.bodyToMono(String.class);
                    } else {
                        return response.bodyToMono(ErrorResponseDTO.class);
                    }
                })
                .timeout(Duration.ofSeconds(20))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in deleteExpense {} ",e.getMessage());
                    return Mono.empty();
                }).block();
        if(result instanceof ExpenseDTO){
            return result;
        }
        logger.info("The expense could not be deleted");
        /// The resource not found exception will be caught within preauthorize condition itself if found.
        throw new AllExpenseTrackerExceptions((ErrorResponseDTO) result);
    }

    /// This is an internal method of PreAuthorize to hande RBAC
    @Override
    public Object getExpenseOwnerEmail(int expenseId){
        logger.info("Inside the getExpenseOwnerEmail() method in Service");
        Object result = webClient.get()
                .uri("/api/expenses/db/fetchEmail/{expenseId}", expenseId)
                .exchangeToMono(response -> {
                    if (response.statusCode().is2xxSuccessful()) {
                        return response.bodyToMono(String.class);
                    } else {
                        return response.bodyToMono(ErrorResponseDTO.class);
                    }
                })
                .timeout(Duration.ofSeconds(70))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in getExpenseOwnerEmail {} ",e.getMessage());
                    return Mono.empty();
                }).block();
        if(result instanceof String){
            if(!EligibilityAndValidationUtil.getAuthenticatedUser().equals(result)){
                throw new ActionNotAllowedException((String)result);
            }
            return result;
        }
        throw new ResourceNotFoundException((ErrorResponseDTO) result);
    }



}
