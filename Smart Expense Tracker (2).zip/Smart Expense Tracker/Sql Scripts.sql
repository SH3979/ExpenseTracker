CREATE TABLE users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('USER', 'ADMIN') DEFAULT 'USER',
    created_date timestamp,
    last_updated_date timestamp
);

CREATE TABLE categories (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    expense_category VARCHAR(255) NOT NULL UNIQUE,
    created_date timestamp,
    last_updated_date timestamp
);

DROP TABLE expenses;

DROP TABLE categories;

CREATE TABLE expenses (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    amount DECIMAL(10,2) NOT NULL,
    description TEXT NOT NULL,
    user_id BIGINT NOT NULL,
    category_id BIGINT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE,
    created_date timestamp,
    last_updated_date timestamp
);

SELECT * FROM users limit 1000;
SELECT * FROM expenses limit 1000;
SELECT * FROM categories limit 1000;


INSERT INTO users (email, password, role, created_date, last_updated_date) VALUES
('shreya.sharma3979@gmail.com', 'Expense@123',"USER", current_date(), current_date()),
('richa.tripathi@gmail.com', 'Expense@456',"ADMIN", current_date(), current_date()),
('ila.sharma@gmail.com', 'Expense@07!',"USER", current_date(), current_date()),
('Prabha.Sood@gmail.com', 'Expense@09!',"ADMIN", current_date(), current_date());

INSERT INTO categories (expense_category, created_date, last_updated_date) VALUES
("Food",current_date(),current_date()),
("Travel",current_date(),current_date()),
("Shopping",current_date(),current_date()),
("Bills",current_date(),current_date());

INSERT INTO expenses (amount, description, user_id, category_id, created_date, last_updated_date) VALUES
(5000, 'Dinner at Zodiac Bistro', 1, 1, current_date(), current_date()),
(20000.00, 'Flight ticket to Bali', 1, 2, current_date(), current_date()),
(300.00, 'Groceries shopping at mart', 2, 3, current_date(), current_date()),
(30000.00, 'Travel to Kashmir', 3, 2, current_date(), current_date()),
(1500.00, 'Electricity Bill February', 4, 4, current_date(), current_date());

SELECT u.email, e.amount, e.description, c.expense_category from expenses e, categories c, users u where e.category_id=c.id and u.id = e.user_id;