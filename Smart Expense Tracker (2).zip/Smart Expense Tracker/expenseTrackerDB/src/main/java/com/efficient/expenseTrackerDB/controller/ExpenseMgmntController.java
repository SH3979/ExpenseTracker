package com.efficient.expenseTrackerDB.controller;

import com.efficient.expenseTrackerDB.DTO.ExpenseDTO;
import com.efficient.expenseTrackerDB.entity.Expense;
import com.efficient.expenseTrackerDB.service.IExpenseService;
import org.apache.coyote.BadRequestException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/expenses/db")
public class ExpenseMgmntController {

    private static final Logger logger = LoggerFactory.getLogger(ExpenseMgmntController.class);
    private final IExpenseService iExpenseService;

    @Autowired
    public ExpenseMgmntController(IExpenseService iExpenseService){
        this.iExpenseService=iExpenseService;
    }

    @GetMapping("/fetch")
    public ResponseEntity<List<ExpenseDTO>> getAllExpenses(){
       logger.info("Inside the getAllExpenses() method in Controller");
       List<ExpenseDTO> expensesList = iExpenseService.getAllExpenses().stream()
               .map(ExpenseDTO::new).toList();
       return ResponseEntity.ok(expensesList);
    }

    @GetMapping("/fetch/{id}")
    public ResponseEntity<ExpenseDTO> getExpensesById(@PathVariable int id){
        logger.info("Inside the getExpensesById() method in Controller");
        ExpenseDTO expenseDTO = iExpenseService.getExpensesById(id);
        return ResponseEntity.ok(expenseDTO);
    }

    @PostMapping("/add")
    public ResponseEntity<ExpenseDTO> addExpense(@RequestBody ExpenseDTO expenseDTO){
        Expense savedExpense = iExpenseService.addExpense(expenseDTO);
        logger.info("Expense is successfully added! {}", savedExpense);
        return ResponseEntity.ok(new ExpenseDTO(savedExpense));
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<ExpenseDTO> updateExpense(@PathVariable int id, @RequestBody ExpenseDTO expenseDTO){
        Expense updatedExpense = iExpenseService.updateExpense(id, expenseDTO);
        logger.info("Expense is successfully updated! {}", updatedExpense);
        return ResponseEntity.ok(new ExpenseDTO(updatedExpense));
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteExpense(@PathVariable int id){
       logger.info("Inside deleteExpense() in Controller");
       return ResponseEntity.ok(iExpenseService.deleteExpense(id));
    }

    /// This is to fetch the email through expenseID info for security RBAC validation
    @GetMapping("/fetchEmail/{expenseId}")
    public String getExpenseOwnerEmail(@PathVariable  int expenseId){
        logger.info("Inside the getUserEmailById method in Controller");
        return iExpenseService.getExpenseOwnerEmail(expenseId);
    }

}
