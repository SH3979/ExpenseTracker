package com.efficient.expenseTrackerDB.repository;

import com.efficient.expenseTrackerDB.entity.Category;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface CategoriesRepository extends JpaRepository<Category,Integer> {

    Optional<Category> findByExpenseCategory(String expenseCategory);
}
