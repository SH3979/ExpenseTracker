package com.efficient.expenseTrackerDB.service;

import com.efficient.expenseTrackerDB.DTO.CategoryDTO;
import com.efficient.expenseTrackerDB.entity.Category;
import com.efficient.expenseTrackerDB.entity.Expense;
import org.apache.coyote.BadRequestException;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface ICategoryService {

     List<CategoryDTO> getAllCategories();

     CategoryDTO getCategoryById(int id) throws BadRequestException;

     Category addCategory(CategoryDTO categoryDTO) throws BadRequestException;

     Category updateCategory(int id, CategoryDTO categoryDTO) throws BadRequestException;

     boolean deleteCategory(int id) throws BadRequestException;
}
