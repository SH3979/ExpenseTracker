package com.efficient.expenseTrackerDB.service;

import com.efficient.expenseTrackerDB.DTO.CategoryDTO;
import com.efficient.expenseTrackerDB.entity.Category;
import com.efficient.expenseTrackerDB.exceptions.ResourceAlreadyExistsException;
import com.efficient.expenseTrackerDB.exceptions.ResourceNotFoundException;
import com.efficient.expenseTrackerDB.repository.CategoriesRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CategoryMgmntService implements ICategoryService{

    private static final Logger logger = LoggerFactory.getLogger(CategoryMgmntService.class);
    private final CategoriesRepository categoriesRepository;

    @Autowired
    public CategoryMgmntService(CategoriesRepository categoriesRepository){
        this.categoriesRepository = categoriesRepository;
    }

    @Override
    public List<CategoryDTO> getAllCategories(){
        logger.info("Inside the getAllCategories() method in Service");
        return categoriesRepository.findAll().parallelStream().map(CategoryDTO::new).toList();
    }

    @Override
    public CategoryDTO getCategoryById(int id){
        logger.info("Inside the getCategoryById() method in Service");
        Category category = categoriesRepository.findById(id).orElseThrow(() ->
                new ResourceNotFoundException("Category","categoryId",String.valueOf(id)));
        logger.info("Printing categories in  CategoryMgmntService: \n"+ category);
        return new CategoryDTO(category);
    }

    @Override
    @Transactional
    public Category addCategory(CategoryDTO categoryDTO){
        logger.info("Inside addCategory method of Service layer");
        if(categoriesRepository.findById(categoryDTO.getId()).isEmpty()){
            Category category = new Category(categoryDTO.getExpenseCategory());
            return categoriesRepository.save(category);
        }
        throw new ResourceAlreadyExistsException("Category","expenseCategory",
                categoryDTO.getExpenseCategory());
    }

    @Override
    @Transactional
    public Category updateCategory(int id, CategoryDTO categoryDTO){
        logger.info("Inside updateCategory method of Service layer");

        Category existingCategory = categoriesRepository.findById(id).orElseThrow(() ->
                new ResourceNotFoundException("Category","categoryId",String.valueOf(id)));
        existingCategory.setExpenseCategory(categoryDTO.getExpenseCategory());
        return categoriesRepository.save(existingCategory);
    }

    @Override
    @Transactional
    public boolean deleteCategory(int id){
        logger.info("Inside deleteCategory in service layer");
        categoriesRepository.findById(id).orElseThrow(()
                -> new ResourceNotFoundException("Category","categoryId",String.valueOf(id)));
        categoriesRepository.deleteById(id);
        return true;
    }
}
