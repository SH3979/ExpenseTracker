package com.efficient.expenseTrackerDB.service;

import com.efficient.expenseTrackerDB.DTO.UserDTO;
import com.efficient.expenseTrackerDB.entity.User;
import org.apache.coyote.BadRequestException;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface IUserService {

     List<UserDTO> getAllUser();

     UserDTO getUserById(int id);

     User addUser(UserDTO userDTO);

     User updateUser(int id, UserDTO userDTO);

     String deleteUser(int id);

     String getUserEmailById(int userId);
}
