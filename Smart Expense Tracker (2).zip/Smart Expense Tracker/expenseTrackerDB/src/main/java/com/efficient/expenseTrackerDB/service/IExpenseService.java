package com.efficient.expenseTrackerDB.service;

import com.efficient.expenseTrackerDB.DTO.ExpenseDTO;
import com.efficient.expenseTrackerDB.entity.Expense;
import org.apache.coyote.BadRequestException;


import java.util.List;

public interface IExpenseService {

     List<Expense> getAllExpenses();

     ExpenseDTO getExpensesById(int Id);


     Expense addExpense(ExpenseDTO expenseDTO);


     Expense updateExpense(int id, ExpenseDTO expenseDTO);


     String deleteExpense(int id);

     String getExpenseOwnerEmail(int expenseId);
}
