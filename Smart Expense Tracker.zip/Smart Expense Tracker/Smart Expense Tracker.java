Required APIs for Smart Expense Tracker :

************************************************************SECURITY************************************************************
-->> 'User Authentication APIs' (Spring Security + JWT) : 

1. POST /api/auth/refreshToken -> refreshing an expired jwt token
2. POST /api/auth/login -> Login a given User [Request : Email, Password ], Response [JWT Token]

************************************************************SECURITY************************************************************
-->> 'User Profile APIs' : [DONE] at DB layer MS

1. GET /api/users/{id} -> Give response (Can only see his own details), admin can see all

2. GET /api/users/ -> fetch all user details : only admin

3. 'PUT /api/users/profile/update -> Update (UserName, Email) (Can only update his own details), admin can update all

4. DELETE /api/admin/users/{id} -> Delete a user (Can only delete his own details), admin can update all

-->> 'Expense Management APIs' : (A) [DONE] at DB layer MS

1. POST /api/expenses/add -> Adding an Expense [Amount, Category, Description, Date]
2. GET /api/expenses -> Fetching all expenses [No request, only response]
3. GET /api/expenses/{id} -> Get a single expense by ID [ID as request Param]
4. PUT /api/expenses/{id} -> Update an expense for a given ID [Request Body will be Expense entity]
5. DELETE /api/expenses/{id} -> Delete an expense [id is the request param]

*************************************************************************************************
User Controller (Authentication & Profile)
Expense Controller
Category Controller
*******************************************************************************************************
FLOW :

We'll structure the Smart Expense Tracker into three microservices:

1. API Gateway Service

. Uses Spring Cloud Gateway
. Handles authentication and authorization with JWT
. Routes requests to the appropriate microservices

2. Expense Management Service

. Manages Users, Expenses, and Categories
. Implements business logic and interacts with the database

3. Database Service

. Handles Hibernate JPA and MySQL
. Exposes REST endpoints for data persistence


Microservices Communication Flow :

1.1 Authentication & Authorization
The API Gateway handles user profiles, authenticates users with JWT tokens.
If the request is valid, it routes it to the correct microservice.

1.2 Expense Management Service Flow
The Expense Management Service expenses, and categories.
It communicates with the Database Service for CRUD operations.

1.3 Database Service Flow
Expense Management Service calls Database Service via REST APIs to store and retrieve data.

************************************************************************************************************
ARCHITECTURE :

Client (React/Angular/Postman)  
   │  
   ▼  
[Spring Cloud Gateway]  ---> Auth & Routing and Users should be maintained here.
   │  
   ├──> [Expense Management Service]  ---> Expenses, Categories  
   │        └──> Calls Database Service for persistence  
   │  
   └──> [Database Service]  ---> Hibernate + MySQL  

************************************************************************************************************   

I will create a secure layer later as that will be an enhanced feature, I will first create 2 microservices 

1) Expsene mgmnt

2) DB service to get started.

then will add another MS for spring cloud gateway later.

************************************************************************************************************

✅ Use @JsonIgnore on @ManyToOne relationships in DTOs to avoid infinite recursion.
✅ Enable CascadeType.ALL for related entities where applicable.
✅ Use DTOs & Services instead of exposing entities directly in controllers.
✅ Implement Soft Delete (instead of hard delete) using a deleted flag.
✅ Add audit fields (createdAt, updatedAt) using Spring’s @PrePersist and @PreUpdate.
✅ Repository Layer
✔️ CRUD operations using JpaRepository.
✔️ Custom queries using findByUserId(), findByEmail(), etc.
✅ Service Layer
✔️ Business logic for handling users, expenses, budgets, reports, and transactions.
✔️ Uses @Autowired to inject repositories.
✔️ Exception handling (RuntimeException) for constraints (e.g., duplicate emails).

-->> Try to see if I can add any custom annotation for any specific type of validation. 
*******************************************************************************************************

@Data is a convenient shortcut annotation that bundles the features of @ToString , @EqualsAndHashCode , @Getter / @Setter and @RequiredArgsConstructor together


---->>

Customized annotation for validation
Multithreading
Exception Handling
OpenAPI documentation
logging
security aspects
Restrict the DB APIs to be hit directly : See how we can do that 
See what common utilities can be included as well 

***************************************************************
Since the Spring security layer is not implemented as of now, I am adding ther userID while adding an expense manually in the code. Once the Spring security is implemented, The user will be automatically taken from the logged in user and only for themselves they will be able to add an expense, not for any other userID.
**************************************************************************************
-->> All the expense APIs are done : CRUD operations [without security layer]

-->> Starting with User -> all crud operations , deleting user should delete the expenses , not category , so delete type cascade

-->> All the CRUD operations + what all expenses a given user has with category [lazy fetch]

-->> If you only want to prevent a field from being included in JSON responses (serialization) but still allow JSON to set it, use @JsonProperty(access = JsonProperty.Access.WRITE_ONLY) instead of @JsonIgnore.

-->> Introduce interfaces to make it more generic that will show loose coupling : DONE

-----------> Expense DB tracker main app is done! 

Exception Handling, Validation handling and custom annotation pending

--->> Expense tracker main app is done!

Exception Handling, Validation handling, custom annotation pending, security layer is pending

--------------------------------->>
What all I need for security layer :

csrf cookie filter : disabled
cors : seyup
securityconfigs for api controls, here
-->> every request coming in needs to be checked through the JWT token if it contains the correct username and password
-->> this will be done through a filter and then this filter should be added as part of my filter chain in security config
-->> 
jwt token

For security layer, I need :

. Authentication : use JWT token [stateless] -> this needs to be updated in security config too 
. Authorizationm : RBAC [USER/ADMIN] dependent APIs accessibility [controller using @Preauthorized or security filter]
. API Security

UsernamePasswordauthenticaitonFilter
JWTTokenUtil
Security config


🔹 JWT is stateless, but we still set the authentication object to ensure Spring Security can process authorization correctly.
🔹 SecurityContext only holds authentication for the request lifecycle, and it’s cleared after the request.
🔹 Without setting authentication, method-level security and role-based authorization won’t work.

🚀 TL;DR: Even in JWT-based authentication, we set the authentication object in SecurityContext to allow Spring Security to process authorization during the request lifecycle, even though we don’t use sessions.

-----------------------------------------------------------------------------------------

-->> Work on RBAC/Authorization policies based on ROLE : Today : DONE
-->> Implement negative scenario global exceptional handling : Today
-->> Start with DSA preparation : Today
-->> Remaining topics of multithreading : Today 
-->> OpenAPI documentation 
****************************************************************************************

-->> Implement custom annotation for validation : Tomorrow
-->> See if I can use multithreading anywhere in the project : Tomorrow
-->> implement refresh token

-----------------------------------------------------------------------------------------
RBAC : Verified, all are working , Now I have to implement proper error handling of these scenarios (negative scenarios)

Admin :

-->> add a user -> USER CREATE : WORKING
-->> View all users profile : WORKING
-->> View a given user profile : WORKING
-->> View all users expenses
-->> Create a category
-->> update a category 
-->> delete a catrgory
-->> view all categories : USER, ADMIN
-->>> view a category : USER, ADMIN

User :  

-->> Update own user  
-->> delete own user
-->> view only its user profile

-->> adding an expense
-->> update own expenses
-->> delete own expenses
-->> view own single expense / expenses

-->> view a given category : USER, ADMIN
-->> view all categories : USER, ADMIN


-->> Admin can update the role of any user but user himself should not be able to do so : DONE
-->> Give an error if someone tries to set any ROLE apart from allowed ones : all errors need to be set properly

-------------------------------------------
-->> Implement all the error scenarios handling
-->> OpenAPI docuemntation to understand 
-->> See how can I include scheduling
-->> How can I include multithreading
**********************************************Handling negative cases and validations********************************************
-->> Identify all the negative scenarios and how those can be handled.
-->> Create 1 common ErrorResponseDTO to show the error
-->> Create custom exceptions like ResourceNotFoundException when a given data does not exist in tehe DB
-->> Implement validation on the given fields and also implement a custom annotation for validation if possible

**************************************************************************************************************************
Purpose of ParameterizedTypeReference in Java
ParameterizedTypeReference<T> is a helper class in Spring that allows you to preserve generic type information at runtime. It is primarily used with Spring's RestTemplate and WebClient to correctly deserialize responses containing generic types like List<T>, Map<K, V>, or ResponseEntity<T>.

Why is it Needed?
In Java, due to type erasure, generic type information (List<String>, Map<Integer, User>, etc.) is lost at runtime. This makes it difficult for Spring's RestTemplate or WebClient to deserialize responses correctly. ParameterizedTypeReference solves this problem by preserving type information at runtime.
**************************************************************************************************************************






