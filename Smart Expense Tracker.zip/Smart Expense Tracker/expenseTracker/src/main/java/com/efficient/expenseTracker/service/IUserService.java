package com.efficient.expenseTracker.service;

import com.efficient.expenseTracker.DTO.UserDTO;

import java.util.List;

public interface IUserService {

     List<UserDTO> getAllUsers();

    Object getUserById(int id);

    Object addUser(UserDTO userDTO);

    Object updateUser(int id, UserDTO userDTO);

    Object deleteUser(int id);

    Object getUserEmailById(int userId);
}
