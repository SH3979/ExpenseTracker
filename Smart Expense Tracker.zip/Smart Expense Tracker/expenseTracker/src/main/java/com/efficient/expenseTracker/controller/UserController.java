package com.efficient.expenseTracker.controller;

import com.efficient.expenseTracker.DTO.ErrorResponseDTO;
import com.efficient.expenseTracker.DTO.UserDTO;
import com.efficient.expenseTracker.exceptions.ResourceAlreadyExistsException;
import com.efficient.expenseTracker.exceptions.ResourceNotFoundException;
import com.efficient.expenseTracker.service.IUserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/user")
public class UserController {

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);
    private final IUserService iUserService;

    @Autowired
    public UserController(IUserService iUserService){
        this.iUserService=iUserService;
    }

    @PreAuthorize("hasAuthority('ADMIN')")
    @GetMapping("/fetch")
    public ResponseEntity<List<UserDTO>> getAllUser(){
        logger.info("Inside the getAllUsers() method in Controller");
        List<UserDTO> usersList = iUserService.getAllUsers();
        return ResponseEntity.ok(usersList);
    }

    @PreAuthorize("@userMgmntService.getUserEmailById(#id) == authentication.principal.username or hasAuthority('ADMIN')")
    @GetMapping("/fetch/{id}")
    public ResponseEntity<UserDTO> getUserById(@PathVariable int id){
        logger.info("Inside the getUserById() method in Controller");
        Object userDTO = iUserService.getUserById(id);
        if(userDTO instanceof UserDTO){
            logger.info("User is fetched successfully {}",userDTO);
            return ResponseEntity.ok((UserDTO) userDTO);
        }
        logger.info("User could not be fetched successfully");
        throw new ResourceNotFoundException((ErrorResponseDTO) userDTO);

    }

    @PreAuthorize("hasAuthority('ADMIN')")
    @PostMapping("/add")
    public ResponseEntity<UserDTO> addUser(@RequestBody UserDTO userDTO){
        logger.info("Inside the addUser method in Controller");
        Object savedUser = iUserService.addUser(userDTO);
        if(savedUser instanceof UserDTO){
            logger.info("User is added successfully {}",savedUser);
            return ResponseEntity.ok((UserDTO) savedUser);
        }
        logger.info("User could not be added successfully");
        throw new ResourceAlreadyExistsException((ErrorResponseDTO) savedUser);
    }

    @PreAuthorize("#userDTO.email == authentication.principal.username and @userMgmntService.getUserEmailById(#id) == authentication.principal.username")
    @PutMapping("/update/{id}")
    public ResponseEntity<UserDTO> updateUser(@PathVariable int id, @RequestBody UserDTO userDTO){
        logger.info("Inside the updateUser method in Controller");
        Object updatedUser = iUserService.updateUser(id, userDTO);
        if(updatedUser instanceof UserDTO){
            logger.info("User is updated successfully {}",updatedUser);
            return ResponseEntity.ok((UserDTO) updatedUser);
        }
        logger.info("User could not be updated successfully");
        throw new ResourceNotFoundException((ErrorResponseDTO) updatedUser);
    }

    @PreAuthorize("@userMgmntService.getUserEmailById(#id) == authentication.principal.username or hasAuthority('ADMIN')")
    @DeleteMapping("/delete/{id}")
    public String deleteUser(@PathVariable int id){
        logger.info("Inside deleteUser() in Controller");
        Object result  = iUserService.deleteUser(id);
        if(result instanceof String){
            logger.info("User is deleted successfully");
            return (String) result;
        }
        logger.info("User could not be deleted successfully");
        throw new ResourceNotFoundException((ErrorResponseDTO) result);

    }

    @GetMapping("/test")
    public ResponseEntity<?> testAuth() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return ResponseEntity.ok(auth);
    }
}
