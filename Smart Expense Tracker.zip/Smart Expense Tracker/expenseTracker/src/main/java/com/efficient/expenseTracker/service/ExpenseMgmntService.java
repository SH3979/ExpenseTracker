package com.efficient.expenseTracker.service;

import com.efficient.expenseTracker.DTO.ErrorResponseDTO;
import com.efficient.expenseTracker.DTO.ExpenseDTO;
import com.efficient.expenseTracker.exceptions.ResourceNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.List;

@Service
public class ExpenseMgmntService implements IExpenseService{

    private final WebClient webClient;

    @Autowired
    public ExpenseMgmntService(WebClient webClient){

        this.webClient=webClient;
    }

    private static final Logger logger = LoggerFactory.getLogger(ExpenseMgmntService.class);


    @Override
    public List<ExpenseDTO> getAllExpenses(){
        logger.info("Inside the getAllExpenses() method in Service");

        return webClient.get()
                .uri("/api/expenses/db/fetch")
                .retrieve().bodyToFlux(ExpenseDTO.class)
                .timeout(Duration.ofSeconds(70))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in getAllExpenses {} ",e.getMessage());
                    return Mono.empty();
                }).collectList().block();
    }

    @Override
    public Object getExpensesById(int id) {
        logger.info("Inside the getExpensesById() method in Service");
        return webClient.get()
                .uri("/api/expenses/db/fetch/{id}", id)
                .retrieve().bodyToMono(Object.class)
                .timeout(Duration.ofSeconds(70))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in getExpensesById {} ",e.getMessage());
                    return Mono.empty();
                }).block();
    }

    @Override
    public Object addExpense(ExpenseDTO expenseDTO){
        logger.info("Inside addExpense method of Service layer");
        logger.info("Printing the response received from the expenseDTO: \n {}",expenseDTO);
        return webClient.post().uri("/api/expenses/db/add")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(expenseDTO).retrieve().bodyToMono(Object.class)
                .timeout(Duration.ofSeconds(20))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in addExpense {} ",e.getMessage());
                    return Mono.empty();
                }).block();
    }

    @Override
    public Object updateExpense(int id, ExpenseDTO expenseDTO){

        logger.info("Inside updateExpense method of Service layer");
        return webClient.put()
                .uri("/api/expenses/db/update/{id}", id)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(expenseDTO)
                .retrieve()
                .bodyToMono(Object.class)
                .timeout(Duration.ofSeconds(20))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in updateExpense {} ",e.getMessage());
                    return Mono.empty();
                }).block();
    }

    @Override
    public Object deleteExpense(int id){
        logger.info("Inside deleteExpense in service layer");
        return webClient.delete()
                .uri("/api/expenses/db/delete/{id}", id)
                .retrieve()
                .bodyToMono(Object.class)
                .timeout(Duration.ofSeconds(20))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in deleteExpense {} ",e.getMessage());
                    return Mono.empty();
                }).block();
    }

    /// This is an internal method of PreAuthorize to hande RBAC
    @Override
    public Object getExpenseOwnerEmail(int expenseId){
        logger.info("Inside the getExpenseOwnerEmail() method in Service");
        Object result = webClient.get()
                .uri("/api/expenses/db/fetchEmail/{expenseId}", expenseId)
                .retrieve().bodyToMono(String.class)
                .timeout(Duration.ofSeconds(70))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in getExpenseOwnerEmail {} ",e.getMessage());
                    return Mono.empty();
                }).block();
        if(result instanceof String){
            return result;
        }
        throw new ResourceNotFoundException((ErrorResponseDTO) result);
    }



}
