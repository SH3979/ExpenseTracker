package com.efficient.expenseTracker.configs;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

/// This class is to return the instance of Webclient
/// in order to communicate with other microservices
@Configuration
public class WebClientConfig {

    @Value("${expenseDB-service.base-url}") // Load from properties
    private String userServiceBaseUrl;

    @Bean
    public WebClient webClient(WebClient.Builder builder) {
        return builder.baseUrl(userServiceBaseUrl).build();
    }

}
