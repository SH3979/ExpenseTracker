package com.efficient.expenseTracker.controller;

import com.efficient.expenseTracker.DTO.CategoryDTO;
import com.efficient.expenseTracker.DTO.ErrorResponseDTO;
import com.efficient.expenseTracker.exceptions.ResourceAlreadyExistsException;
import com.efficient.expenseTracker.exceptions.ResourceNotFoundException;
import com.efficient.expenseTracker.service.ICategoryService;
import org.apache.coyote.BadRequestException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/categories")
public class CategoryController {

    private static final Logger logger = LoggerFactory.getLogger(CategoryController.class);
    private final ICategoryService iCategoryService;

    public CategoryController(ICategoryService iCategoryService) {
        this.iCategoryService = iCategoryService;
    }
    @PreAuthorize("hasAnyAuthority('USER', 'ADMIN')")
    @GetMapping("/fetch")
    public ResponseEntity<List<CategoryDTO>> getAllCategories(){
        logger.info("Inside the getAllCategories() method in Controller");
        List<CategoryDTO> categoryList = iCategoryService.getAllCategories();
        return ResponseEntity.ok(categoryList);
    }

    @PreAuthorize("hasAnyAuthority('USER', 'ADMIN')")
    @GetMapping("/fetch/{id}")
    public ResponseEntity<CategoryDTO> getCategoryById(@PathVariable int id) throws BadRequestException {
        logger.info("Inside the getCategoryById() method in Controller");
        Object categoryDTO = iCategoryService.getCategoryById(id);
        if(categoryDTO instanceof CategoryDTO){
            logger.info("Category is fetched successfully {}",categoryDTO);
            return ResponseEntity.ok((CategoryDTO) categoryDTO);
        }
        logger.info("Category could not be fetched successfully");
        throw new ResourceNotFoundException((ErrorResponseDTO) categoryDTO);

    }

    @PreAuthorize("hasAuthority('ADMIN')")
    @PostMapping("/add")
    public ResponseEntity<CategoryDTO> addCategory(@RequestBody CategoryDTO categoryDTO) throws BadRequestException {
        logger.info("Inside the addCategory method in Controller");
        Object savedCategory = iCategoryService.addCategory(categoryDTO);
        if(savedCategory instanceof CategoryDTO){
            logger.info("Category is added successfully {}",savedCategory);
            return ResponseEntity.ok((CategoryDTO) savedCategory);
        }
        logger.info("Category could not be added successfully");
        throw new ResourceAlreadyExistsException((ErrorResponseDTO) savedCategory);

    }

    @PreAuthorize("hasAuthority('ADMIN')")
    @PutMapping("/update/{id}")
    public ResponseEntity<CategoryDTO> updateCategory(@PathVariable int id, @RequestBody CategoryDTO categoryDTO ) throws BadRequestException {
        logger.info("Inside the updateCategory method in Controller");
        Object updatedCategory = iCategoryService.updateCategory(id, categoryDTO);
        if(updatedCategory instanceof CategoryDTO){
            logger.info("Category is updated successfully {}",updatedCategory);
            return ResponseEntity.ok((CategoryDTO) updatedCategory);
        }
        logger.info("Category could not be updated successfully");
        throw new ResourceNotFoundException((ErrorResponseDTO) updatedCategory);

    }

    @PreAuthorize("hasAuthority('ADMIN')")
    @DeleteMapping("/delete/{id}")
    public String deleteCategory(@PathVariable int id) throws BadRequestException {
        logger.info("Inside deleteUser() in Controller");
        Object result = iCategoryService.deleteCategory(id);
        if(result instanceof String){
            logger.info("Category is deleted successfully");
            return (String) result;
        }
        logger.info("Category could not be deleted successfully");
        throw new ResourceNotFoundException((ErrorResponseDTO) result);
    }
}
