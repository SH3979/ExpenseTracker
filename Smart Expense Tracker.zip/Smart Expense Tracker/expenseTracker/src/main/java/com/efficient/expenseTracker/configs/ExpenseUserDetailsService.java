package com.efficient.expenseTracker.configs;

import com.efficient.expenseTracker.DTO.LoginRequestDTO;
import com.efficient.expenseTracker.exceptions.AuthenticationFailedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;
import java.util.Map;


@Component
public class ExpenseUserDetailsService implements UserDetailsService{

    private final WebClient webClient;
    private static final Logger logger = LoggerFactory.getLogger(ExpenseUserDetailsService.class);

    @Autowired
    public ExpenseUserDetailsService(WebClient webClient){

        this.webClient=webClient;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        logger.info("The method is being called internally by authenticate method of authentication mgr");
        LoginRequestDTO loginRequestDTO = new LoginRequestDTO(username, null);
        Map<String, String> responseMap = webClient.post().uri("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(loginRequestDTO).retrieve().bodyToMono
                        (new ParameterizedTypeReference<Map<String, String>>() {}).block();
        logger.info("Printing the data in the response map: {} \n",responseMap.get("username")+" and "+
                responseMap.get("password")+" and "+responseMap.get("role"));
        return mapToUserDetails(responseMap);
    }

    private UserDetails mapToUserDetails(Map<String, String> userDetailsMap) {
        logger.info("Inside mapToUserDetails method");
        String username =  userDetailsMap.get("username");
        String password = userDetailsMap.get("password");
        String role = userDetailsMap.get("role");

        if(role == null){
            throw new AuthenticationFailedException("User","username", username);
        }
        GrantedAuthority authority = new SimpleGrantedAuthority(role);

        List<GrantedAuthority> authorities = List.of(authority);
        return new UserDetailsImpl(username, password, authorities);
    }
}
