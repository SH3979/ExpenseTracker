package com.efficient.expenseTracker.service;

import com.efficient.expenseTracker.DTO.CategoryDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.List;

@Service
public class CategoryMgmntService implements ICategoryService{

    private final WebClient webClient;

    @Autowired
    public CategoryMgmntService(WebClient webClient){

        this.webClient=webClient;
    }

    private static final Logger logger = LoggerFactory.getLogger(CategoryMgmntService.class);

    @Override
    public List<CategoryDTO> getAllCategories(){
        logger.info("Inside the getAllCategories() method in Service");
        return webClient.get()
                .uri("/api/categories/db/fetch")
                .retrieve().bodyToFlux(CategoryDTO.class)
                .timeout(Duration.ofSeconds(20))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in getAllCategories {} ",e.getMessage());
                    return Mono.empty();
                }).collectList().block();
    }

    @Override
    public Object getCategoryById(int id){
        logger.info("Inside the getCategoryById() method in Service");
        return webClient.get()
                .uri("/api/categories/db/fetch/{id}", id)
                .retrieve().bodyToMono(Object.class)
                .timeout(Duration.ofSeconds(70))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in getCategoryById {} ",e.getMessage());
                    return Mono.empty();
                }).block();
    }

    @Override
    public Object addCategory(CategoryDTO categoryDTO){
        logger.info("Inside addCategory method of Service layer");
        return webClient.post().uri("/api/categories/db/add")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(categoryDTO).retrieve().bodyToMono(Object.class)
                .timeout(Duration.ofSeconds(70))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in addCategory {} ",e.getMessage());
                    return Mono.empty();
                }).block();
    }

    @Override
    public Object updateCategory(int id, CategoryDTO categoryDTO) {
        logger.info("Inside updateCategory method of Service layer");
        return webClient.put()
                .uri("/api/categories/db/update/{id}", id)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(categoryDTO)
                .retrieve()
                .bodyToMono(Object.class)
                .timeout(Duration.ofSeconds(70))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in updateCategory {} ",e.getMessage());
                    return Mono.empty();
                }).block();

    }

    @Override
    public Object deleteCategory(int id) {
        logger.info("Inside deleteCategory in service layer");
        return webClient.delete()
                .uri("/api/categories/db/delete/{id}", id)
                .retrieve()
                .bodyToMono(Object.class)
                .timeout(Duration.ofSeconds(70))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in deleteCategory {} ",e.getMessage());
                    return Mono.empty();
                }).block();
    }

}
