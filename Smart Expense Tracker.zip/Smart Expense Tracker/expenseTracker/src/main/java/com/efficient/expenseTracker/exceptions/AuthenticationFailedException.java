package com.efficient.expenseTracker.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.UNAUTHORIZED)
public class AuthenticationFailedException extends RuntimeException{

    public AuthenticationFailedException(String resourceName, String fieldName, String fieldValue){
        super(String.format("Login for %s with %s : '%s' has failed.", resourceName,
                fieldName, fieldValue));
    }
}
