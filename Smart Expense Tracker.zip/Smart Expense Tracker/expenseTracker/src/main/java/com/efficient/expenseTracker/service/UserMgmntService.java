package com.efficient.expenseTracker.service;

import com.efficient.expenseTracker.DTO.ErrorResponseDTO;
import com.efficient.expenseTracker.DTO.UserDTO;
import com.efficient.expenseTracker.exceptions.ResourceNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.List;

@Service
public class UserMgmntService implements IUserService{

    private final WebClient webClient;
    private PasswordEncoder passwordEncoder;

    @Autowired
    public UserMgmntService(WebClient webClient, PasswordEncoder passwordEncoder){
        this.webClient=webClient;
        this.passwordEncoder = passwordEncoder;
    }

    private static final Logger logger = LoggerFactory.getLogger(UserMgmntService.class);

    @Override
    public List<UserDTO> getAllUsers(){
        logger.info("Inside the getAllUser() method in Service");
        return webClient.get()
                .uri("/api/User/db/fetch")
                .retrieve().bodyToFlux(UserDTO.class)
                .timeout(Duration.ofSeconds(70))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in getAllUsers {} ",e.getMessage());
                    return Mono.empty();
                }).collectList().block();
    }

    @Override
    public Object getUserById(int id){
        logger.info("Inside the getUserById() method in Service");
        return webClient.get()
                .uri("/api/User/db/fetch/{id}", id)
                .retrieve().bodyToMono(Object.class)
                .timeout(Duration.ofSeconds(70))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in getUserById {} ",e.getMessage());
                    return Mono.empty();
                }).block();
    }

    @Override
    public Object addUser(UserDTO userDTO){
        logger.info("Printing the user to be added { \n {}",userDTO);
        logger.info("Inside addUser method of Service layer");
        userDTO.setPassword(passwordEncoder.encode(userDTO.getPassword()));
        return webClient.post().uri("/api/User/db/add")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(userDTO).retrieve().bodyToMono(Object.class)
                .timeout(Duration.ofSeconds(70))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in addUser {} ",e.getMessage());
                    return Mono.empty();
                }).block();
    }

    @Override
    public Object updateUser(int id, UserDTO userDTO) {
        logger.info("Inside updateUser method of Service layer");
        userDTO.setPassword(passwordEncoder.encode(userDTO.getPassword()));
        /// Prevent users from updating their role
        if (isRoleModified(userDTO)){
            throw new SecurityException("You are not allowed to update the role!");
        }
        return webClient.put()
                .uri("/api/User/db/update/{id}", id)
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(userDTO)
                .retrieve()
                .bodyToMono(Object.class)
                .timeout(Duration.ofSeconds(70))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in updateUser {} ",e.getMessage());
                    return Mono.empty();
                }).block();

    }

    @Override
    public Object deleteUser(int id) {
        logger.info("Inside deleteUser in service layer");
        return webClient.delete()
                .uri("/api/User/db/delete/{id}", id)
                .retrieve()
                .bodyToMono(Object.class)
                .timeout(Duration.ofSeconds(20))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in delete user {} ",e.getMessage());
                    return Mono.just("Error deleting user");
                }).block();
    }

    /// This is used internally within PreAuthorize for RBAC
    @Override
    public Object getUserEmailById(int userId){
        logger.info("Inside the getUserEmailById() method in Service");
        Object result = webClient.get()
                .uri("/api/User/db/fetchEmail/{userId}", userId)
                .retrieve().bodyToMono(Object.class)
                .timeout(Duration.ofSeconds(70))
                .onErrorResume(WebClientResponseException.class, e -> {
                    logger.info("Error in getUserEmailById {} ",e.getMessage());
                    return Mono.empty();
                }).block();
        if(result instanceof String){
            return result;
        }
        throw new ResourceNotFoundException((ErrorResponseDTO) result);
    }

    private boolean isRoleModified(UserDTO userDTO){

        String role = SecurityContextHolder.getContext().getAuthentication()
                .getAuthorities().stream().toList().getFirst().toString();

        return !role.equals(userDTO.getRole());
    }
}
