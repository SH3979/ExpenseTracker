package com.efficient.expenseTracker.service;

import com.efficient.expenseTracker.DTO.ExpenseDTO;
import org.apache.coyote.BadRequestException;

import java.util.List;

public interface IExpenseService {

     List<ExpenseDTO> getAllExpenses();

     Object getExpensesById(int Id);

     Object addExpense(ExpenseDTO expense);

     Object updateExpense(int id, ExpenseDTO expense);

     Object deleteExpense(int Id) throws BadRequestException;

     Object getExpenseOwnerEmail(int expenseId);
}

