package com.efficient.expenseTracker.controller;

import com.efficient.expenseTracker.DTO.ErrorResponseDTO;
import com.efficient.expenseTracker.DTO.ExpenseDTO;
import com.efficient.expenseTracker.exceptions.ResourceNotFoundException;
import com.efficient.expenseTracker.service.IExpenseService;
import org.apache.coyote.BadRequestException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/expenses")
public class ExpenseMgmntController {

    private static final Logger logger = LoggerFactory.getLogger(ExpenseMgmntController.class);
    private final IExpenseService iExpenseService;

    @Autowired
    public ExpenseMgmntController(IExpenseService iExpenseService){
        this.iExpenseService=iExpenseService;
    }

    @PreAuthorize("hasAuthority('ADMIN')")
    @GetMapping("/fetch")
    public ResponseEntity<List<ExpenseDTO>> getAllExpenses(){
        logger.info("Inside the getAllExpenses() method in Controller");
        return ResponseEntity.ok(iExpenseService.getAllExpenses());
    }

    @PreAuthorize("@expenseMgmntService.getExpenseOwnerEmail(#id) == authentication.principal.username or hasAuthority('ADMIN')")
    @GetMapping("/fetch/{id}")
    public ResponseEntity<ExpenseDTO> getExpensesById(@PathVariable int id) {
        logger.info("Inside the getExpensesById() method in Controller");
        Object expenseDTO = iExpenseService.getExpensesById(id);
        if(expenseDTO instanceof ExpenseDTO){
            logger.info("Expense is fetched successfully {}",expenseDTO);
            return ResponseEntity.ok((ExpenseDTO) expenseDTO);
        }
        logger.info("Expense could not be fetched successfully");
        throw new ResourceNotFoundException((ErrorResponseDTO) expenseDTO);

    }

    @PreAuthorize("#expenseDTO.email == authentication.principal.username")
    @PostMapping("/add")
    public ResponseEntity<ExpenseDTO> addExpense(@RequestBody ExpenseDTO expenseDTO) throws BadRequestException {
        Object savedExpense = iExpenseService.addExpense(expenseDTO);
        if(savedExpense instanceof ExpenseDTO){
            logger.info("Expense is added successfully {}",savedExpense);
            return ResponseEntity.ok((ExpenseDTO) savedExpense);
        }
        logger.info("Expense could not be added successfully");
        throw new ResourceNotFoundException((ErrorResponseDTO) savedExpense);

    }

    @PreAuthorize("#expenseDTO.email == authentication.principal.username and @expenseMgmntService.getExpenseOwnerEmail(#id) == authentication.principal.username")
    @PutMapping("/update/{id}")
    public ResponseEntity<ExpenseDTO> updateExpense(@PathVariable int id, @RequestBody ExpenseDTO expenseDTO)
            throws BadRequestException {
        Object updatedExpense = iExpenseService.updateExpense(id, expenseDTO);
        if(updatedExpense instanceof ExpenseDTO){
            logger.info("Expense is updated successfully {}",updatedExpense);
            return ResponseEntity.ok((ExpenseDTO) updatedExpense);
        }
        logger.info("Expense could not be updated successfully");
        throw new ResourceNotFoundException((ErrorResponseDTO) updatedExpense);

    }

    @PreAuthorize("@expenseMgmntService.getExpenseOwnerEmail(#id) == authentication.principal.username")
    @DeleteMapping("/delete/{id}")
    public String deleteExpense(@PathVariable int id) throws BadRequestException {
        logger.info("Inside deleteExpense() in Controller");
        Object result = iExpenseService.deleteExpense(id);
        if(result instanceof String){
            logger.info("Expense is deleted successfully");
            return (String) result;
        }
        logger.info("Expense could not be deleted successfully");
        throw new ResourceNotFoundException((ErrorResponseDTO) result);
    }

}
