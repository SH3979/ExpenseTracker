package com.efficient.expenseTracker.service;

import com.efficient.expenseTracker.DTO.CategoryDTO;

import java.util.List;

public interface ICategoryService {


     List<CategoryDTO> getAllCategories();


     Object getCategoryById(int id);


    Object addCategory(CategoryDTO categoryDTO);


    Object updateCategory(int id, CategoryDTO categoryDTO);


     Object deleteCategory(int id);

}
