package com.efficient.expenseTracker.DTO;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

public class UserDTO {

    private int id;

    private String email;

    private String role;

    /// This will be part of JSON only if it is not null
    /// which will never be the case since we are never reading the password
    /// value from the DB MS
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String password;

    private List<ExpenseDTO> expenses;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public List<ExpenseDTO> getExpenses() {
        return expenses;
    }

    public void setExpenses(List<ExpenseDTO> expenses) {
        this.expenses = expenses;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {

        this.password = password;

    }

    @Override
    public String toString() {
        return "UserDTO{" +
                "id=" + id +
                ", email='" + email + '\'' +
                ", role='" + role + '\'' +
                ", password='" + password + '\'' +
                ", expenses=" + expenses +
                '}';
    }
}
