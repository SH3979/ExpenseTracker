package com.efficient.expenseTrackerDB.configs;

import com.efficient.expenseTrackerDB.entity.User;
import com.efficient.expenseTrackerDB.exceptions.AuthenticationFailedException;
import com.efficient.expenseTrackerDB.repository.UsersRepository;
import org.springframework.stereotype.Component;

@Component
public class ExpenseUserDetailsService{

    private final UsersRepository usersRepository;

    public ExpenseUserDetailsService(UsersRepository usersRepository) {
        this.usersRepository = usersRepository;
    }

    public User loadUserByUsername(String username){
        return usersRepository.findByEmail(username)
                .orElseThrow(AuthenticationFailedException::new);

    }
}
