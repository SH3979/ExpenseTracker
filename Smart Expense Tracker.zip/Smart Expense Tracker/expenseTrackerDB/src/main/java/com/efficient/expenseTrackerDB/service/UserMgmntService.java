package com.efficient.expenseTrackerDB.service;

import com.efficient.expenseTrackerDB.DTO.UserDTO;
import com.efficient.expenseTrackerDB.entity.User;
import com.efficient.expenseTrackerDB.exceptions.ResourceAlreadyExistsException;
import com.efficient.expenseTrackerDB.exceptions.ResourceNotFoundException;
import com.efficient.expenseTrackerDB.repository.UsersRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class UserMgmntService implements IUserService{

    private static final Logger logger = LoggerFactory.getLogger(UserMgmntService.class);
    private final UsersRepository usersRepository;

    @Autowired
    public UserMgmntService(UsersRepository usersRepository){
        this.usersRepository = usersRepository;
    }


    @Override
    public List<UserDTO> getAllUser(){
        logger.info("Inside the getAllUser() method in Service");
        /// This constructor call of UserDTO should take care of the lazy fetching of expenses for the user.
        return usersRepository.findAll().stream().map(UserDTO::new).toList();
    }

    @Override
    public UserDTO getUserById(int id){
        logger.info("Inside the getUserById() method in Service");
        User user = usersRepository.findById(id).orElseThrow(() -> new
                ResourceNotFoundException("User","userId",String.valueOf(id)));
        logger.info("Printing users in  UserMgmntService: \n"+ user);
        return new UserDTO(user);
    }

    @Override
    @Transactional
    public User addUser(UserDTO userDTO){
        logger.info("Inside addUser method of Service layer");
        if(usersRepository.findByEmail(userDTO.getEmail()).isEmpty()){
            User user = new User(userDTO.getEmail(), userDTO.getPassword(), userDTO.getRole());
            return usersRepository.save(user);
        }
        throw new ResourceAlreadyExistsException("User","email",userDTO.getEmail());
    }

    @Override
    @Transactional
    public User updateUser(int id, UserDTO userDTO){
        logger.info("Inside updateUser method of Service layer");

        User existingUser = usersRepository.findById(id).orElseThrow(() ->
                new ResourceNotFoundException("User","email",userDTO.getEmail()));
        existingUser.setEmail(userDTO.getEmail());
        existingUser.setRole(userDTO.getRole());
        existingUser.setPassword(userDTO.getPassword());
        return usersRepository.save(existingUser);
    }

    @Override
    @Transactional
    public boolean deleteUser(int id){
        logger.info("Inside deleteUser in service layer");
        usersRepository.findById(id).orElseThrow(()
                -> new ResourceNotFoundException("User","userId",String.valueOf(id)));
        usersRepository.deleteById(id);
        return true;
    }

    @Override
    @Transactional
    public String getUserEmailById(int userId){
        return usersRepository.findById(userId)
                .map(User::getEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User","userId",String.valueOf(userId)));
    }

}

