package com.efficient.expenseTrackerDB.DTO;

import com.efficient.expenseTrackerDB.entity.Category;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Collections;
import java.util.List;

public class CategoryDTO {

    public CategoryDTO() {
    }

    public CategoryDTO(Category category) {
        this.id = category.getId();
        this.expenseCategory = category.getExpenseCategory();
    }

    /// This will allow id as an output in the JSON response but not input JSON request
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private int id;

    private String expenseCategory;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getExpenseCategory() {
        return expenseCategory;
    }

    public void setExpenseCategory(String expenseCategory) {
        this.expenseCategory = expenseCategory;
    }

}
