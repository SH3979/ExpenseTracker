package com.efficient.expenseTrackerDB.service;

import com.efficient.expenseTrackerDB.DTO.UserDTO;
import com.efficient.expenseTrackerDB.entity.User;
import org.apache.coyote.BadRequestException;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface IUserService {

     List<UserDTO> getAllUser();

     UserDTO getUserById(int id) throws BadRequestException;

     User addUser(UserDTO userDTO) throws BadRequestException;

     User updateUser(int id, UserDTO userDTO) throws BadRequestException;

     boolean deleteUser(int id) throws BadRequestException;

     @Transactional
     String getUserEmailById(int userId) throws BadRequestException;
}
