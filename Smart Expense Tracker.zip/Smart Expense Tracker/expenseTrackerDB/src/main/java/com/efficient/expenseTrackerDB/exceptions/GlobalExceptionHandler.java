package com.efficient.expenseTrackerDB.exceptions;

import com.efficient.expenseTrackerDB.DTO.ErrorResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    private final ErrorResponseDTO errorResponseDTO;

    @Autowired
    public GlobalExceptionHandler(ErrorResponseDTO errorResponseDTO) {
        this.errorResponseDTO = errorResponseDTO;
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponseDTO> handleGlobalException(Exception exception,
                         WebRequest webRequest) {
        return new ResponseEntity<>(setErrorResponseData(HttpStatus.INTERNAL_SERVER_ERROR, webRequest, exception),
                HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ErrorResponseDTO> handleResourceNotFoundException(ResourceNotFoundException exception,
                         WebRequest webRequest) {
        return new ResponseEntity<>(setErrorResponseData(HttpStatus.NOT_FOUND, webRequest, exception)
                , HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(ResourceAlreadyExistsException.class)
    public ResponseEntity<ErrorResponseDTO> handleResourceAlreadyExistsException(ResourceAlreadyExistsException exception,
                        WebRequest webRequest) {
        return new ResponseEntity<>(setErrorResponseData(HttpStatus.BAD_REQUEST, webRequest, exception)
                , HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(AuthenticationFailedException.class)
    public ResponseEntity<Map<String, String>> handleAuthenticationFailedException(AuthenticationFailedException exception){
        Map<String, String> emptyUserDetailsMap = new HashMap<>();
        emptyUserDetailsMap.put("username", exception.getMessage().split(":")[1]);
        emptyUserDetailsMap.put("password", null);
        emptyUserDetailsMap.put("role", null);
        /// Sending okay as it will be handled gracefully by main client facing service
        return ResponseEntity.ok(emptyUserDetailsMap);
    }

    private ErrorResponseDTO setErrorResponseData(HttpStatus responseStatus, WebRequest webRequest,
                             Exception exception){
        errorResponseDTO.setApiPath(webRequest.getDescription(false));
        errorResponseDTO.setErrorCode(responseStatus);
        errorResponseDTO.setErrorMessage(exception.getMessage());
        errorResponseDTO.setErrorTime(LocalDateTime.now());
        return errorResponseDTO;
    }

}
