package com.efficient.expenseTrackerDB.controller;

import com.efficient.expenseTrackerDB.DTO.ExpenseDTO;
import com.efficient.expenseTrackerDB.DTO.UserDTO;
import com.efficient.expenseTrackerDB.entity.User;
import com.efficient.expenseTrackerDB.service.IUserService;
import org.apache.coyote.BadRequestException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/User/db")
public class UserController {

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);
    private final IUserService iUserService;

    @Autowired
    public UserController(IUserService iUserService){
        this.iUserService=iUserService;
    }

    @GetMapping("/fetch")
    public ResponseEntity<List<UserDTO>> getAllUser(){
        logger.info("Inside the getAllUsers() method in Controller");
        List<UserDTO> usersList = iUserService.getAllUser();
        return ResponseEntity.ok(usersList);
    }

    @GetMapping("/fetch/{id}")
    public ResponseEntity<UserDTO> getUserById(@PathVariable int id) throws BadRequestException {
        logger.info("Inside the getUserById() method in Controller");
        UserDTO userDTO = iUserService.getUserById(id);
        return ResponseEntity.ok(userDTO);
    }

    /// This is to fetch the email through userId info for security RBAC validation
    @GetMapping("/fetchEmail/{userId}")
    public String getUserEmailById(@PathVariable  int userId) throws BadRequestException {
        logger.info("Inside the getUserEmailById method in Controller");
        return iUserService.getUserEmailById(userId);
    }

    @PostMapping("/add")
    public ResponseEntity<UserDTO> addUser(@RequestBody UserDTO userDTO) throws BadRequestException {
        logger.info("Inside the addUser method in Controller");
        User savedUser = iUserService.addUser(userDTO);
        logger.info("User is successfully added! {}", savedUser);
        return ResponseEntity.ok(new UserDTO(savedUser));
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<UserDTO> updateUser(@PathVariable int id, @RequestBody UserDTO userDTO) throws BadRequestException {
        logger.info("Inside the updateUser method in Controller");
        User updatedUser = iUserService.updateUser(id, userDTO);

        logger.info("User is successfully updated! {}", updatedUser);
        return ResponseEntity.ok(new UserDTO(updatedUser));
    }

    @DeleteMapping("/delete/{id}")
    public String deleteUser(@PathVariable int id) throws BadRequestException {
        logger.info("Inside deleteUser() in Controller");
        boolean isSuccess =iUserService.deleteUser(id);
        if(isSuccess){
            return "The user has been successfully deleted";
        }
        throw new BadRequestException("The user could not be deleted");
    }
}
