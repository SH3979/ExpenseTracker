package com.efficient.expenseTrackerDB.DTO;

import com.efficient.expenseTrackerDB.entity.Expense;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ExpenseDTO {

    public ExpenseDTO() {
    }

    /// This will be used to set the values from Entity to DTO
    /// in order to show the data in JSON
    public ExpenseDTO(Expense expense) {
        this.id = expense.getId();
        this.amount = expense.getAmount();
        this.description = expense.getDescription();
        this.email = expense.getUser().getEmail();
        this.category = expense.getCategory().getExpenseCategory();
    }

    /// This will allow id as an output in the JSON response but not input JSON request
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private int id;

    private double amount;

    private String description;

    private String email;

    private String category;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    @Override
    public String toString() {
        return "ExpenseDTO{" +
                ", amount=" + amount +
                ", description='" + description + '\'' +
                ", email='" + email + '\'' +
                ", category='" + category + '\'' +
                '}';
    }
}
