package com.efficient.expenseTrackerDB.controller;

import com.efficient.expenseTrackerDB.DTO.LoginRequestDTO;
import com.efficient.expenseTrackerDB.configs.ExpenseUserDetailsService;
import com.efficient.expenseTrackerDB.entity.User;
import org.apache.coyote.BadRequestException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthHandlerController {

    private final ExpenseUserDetailsService expenseUserDetailsService;

    public AuthHandlerController(ExpenseUserDetailsService expenseUserDetailsService){
        this.expenseUserDetailsService = expenseUserDetailsService;
    }

    @PostMapping("/login")
    public ResponseEntity<Map<String, String>> loginuser(@RequestBody LoginRequestDTO loginRequestDTO){
        User user = expenseUserDetailsService.loadUserByUsername(loginRequestDTO.getUsername());
        Map<String, String> userDetailsMap = new HashMap<>();
        userDetailsMap.put("username", user.getEmail());
        userDetailsMap.put("password", user.getPassword());
        userDetailsMap.put("role", user.getRole());
        return ResponseEntity.ok(userDetailsMap);
    }
}
