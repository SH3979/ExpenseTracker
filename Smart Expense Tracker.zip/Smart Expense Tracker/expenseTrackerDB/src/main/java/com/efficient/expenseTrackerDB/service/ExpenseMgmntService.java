package com.efficient.expenseTrackerDB.service;

import com.efficient.expenseTrackerDB.DTO.ExpenseDTO;
import com.efficient.expenseTrackerDB.entity.Category;
import com.efficient.expenseTrackerDB.entity.Expense;
import com.efficient.expenseTrackerDB.entity.User;
import com.efficient.expenseTrackerDB.exceptions.ResourceNotFoundException;
import com.efficient.expenseTrackerDB.repository.CategoriesRepository;
import com.efficient.expenseTrackerDB.repository.ExpensesRepository;
import com.efficient.expenseTrackerDB.repository.UsersRepository;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
public class ExpenseMgmntService implements IExpenseService{

    private static final Logger logger = LoggerFactory.getLogger(ExpenseMgmntService.class);

    private final ExpensesRepository expensesRepository;
    private final UsersRepository usersRepository;
    private final CategoriesRepository categoriesRepository;

    @Autowired
    public ExpenseMgmntService(ExpensesRepository expensesRepository
            ,UsersRepository usersRepository,CategoriesRepository categoriesRepository){
        this.expensesRepository = expensesRepository;
        this.usersRepository=usersRepository;
        this.categoriesRepository=categoriesRepository;
    }

    @Override
    public List<Expense> getAllExpenses(){
       logger.info("Inside the getAllExpenses() method in Service");
       return expensesRepository.findAll();
    }

    @Override
    public ExpenseDTO getExpensesById(int id){

        logger.info("Inside the getExpensesById() method in Service");
        Expense expense = expensesRepository.findById(id).orElseThrow(() -> new
                ResourceNotFoundException("Expense","expenseId",String.valueOf(id)));
        logger.info("Printing expense  ExpenseMgmntService: \n"+ expense);
        return new ExpenseDTO(expense);
    }

    @Override
    @Transactional
    public Expense addExpense(ExpenseDTO expenseDTO){
        logger.info("Inside addExpense method of Service layer");

        String userEmail = expenseDTO.getEmail();
        User user = usersRepository.findByEmail(userEmail).orElseThrow(() ->
                new ResourceNotFoundException("User","email",userEmail));

        String expenseCategory = expenseDTO.getCategory();
        Category category = categoriesRepository.findByExpenseCategory(expenseCategory)
                .orElseThrow(() -> new ResourceNotFoundException("Category","expenseCategory",expenseCategory));

        Expense expense = new Expense(expenseDTO.getAmount(),expenseDTO.getDescription(),
                user,category);

        return expensesRepository.save(expense);
    }

    @Override
    @Transactional
    public Expense updateExpense(int id, ExpenseDTO expenseDTO){

        logger.info("Inside updateExpense method of Service layer");

        String userEmail = expenseDTO.getEmail();
        User user = usersRepository.findByEmail(userEmail).orElseThrow(() ->
                new ResourceNotFoundException("User","email",userEmail));

        String expenseCategory = expenseDTO.getCategory();
        Category category = categoriesRepository.findByExpenseCategory(expenseCategory)
                .orElseThrow(() -> new ResourceNotFoundException("Category","expenseCategory",expenseCategory));

        Expense expense = expensesRepository.findById(id).orElseThrow(() ->
                new ResourceNotFoundException("Expense","expenseId",String.valueOf(id)));

        expense.setAmount(expenseDTO.getAmount());
        expense.setDescription(expenseDTO.getDescription());
        expense.setCategory(category);
        expense.setUser(user);

        return expensesRepository.save(expense);
    }

    @Override
    @Transactional
    public boolean deleteExpense(int id){
        logger.info("Inside deleteExpense in service layer");
        expensesRepository.findById(id).orElseThrow(()
                -> new ResourceNotFoundException("Expense","expenseId",String.valueOf(id)));
        expensesRepository.deleteById(id);
        return true;
    }

    @Override
    public String getExpenseOwnerEmail(int expenseId) {
        return expensesRepository.findById(expenseId)
                .map(expense -> expense.getUser().getEmail())
                .orElseThrow(() -> new ResourceNotFoundException("Expense","expenseId",String.valueOf(expenseId)));
    }
}
