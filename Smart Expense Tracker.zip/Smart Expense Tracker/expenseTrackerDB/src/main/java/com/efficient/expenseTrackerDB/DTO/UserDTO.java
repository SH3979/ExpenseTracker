package com.efficient.expenseTrackerDB.DTO;

import com.efficient.expenseTrackerDB.entity.User;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.Collections;
import java.util.List;

@Data
public class UserDTO {

    public UserDTO() {
    }
    /// To maintain the consistency I am accessing the password too, but will not add it to the response
    public UserDTO(User user) {
        this.id = user.getId();
        this.email = user.getEmail();
        this.role = user.getRole();
        this.password = user.getPassword();
        /// Maybe for the expense coming from the db it was already handled.
        this.expenses = user.getExpenses()!=null?user.getExpenses().
                stream().map(ExpenseDTO::new).toList(): Collections.emptyList();
    }

    /// This will allow id as an output in the JSON response but not input JSON request
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private int id;

    private String email;

    private String role;

    /// This will allow password as an input in the JSON request but not out JSON response
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String password;

    /// This will allow expenses as an output in the JSON response but not input JSON request
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private List<ExpenseDTO> expenses;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public List<ExpenseDTO> getExpenses() {
        return expenses;
    }

    public void setExpenses(List<ExpenseDTO> expenses) {
        this.expenses = expenses;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "UserDTO{" +
                "id=" + id +
                ", email='" + email + '\'' +
                ", role='" + role + '\'' +
                ", password='" + password + '\'' +
                ", expenses=" + expenses +
                '}';
    }
}
