package com.efficient.expenseTrackerDB.service;

import com.efficient.expenseTrackerDB.DTO.ExpenseDTO;
import com.efficient.expenseTrackerDB.entity.Expense;
import org.apache.coyote.BadRequestException;


import java.util.List;

public interface IExpenseService {

     List<Expense> getAllExpenses();

     ExpenseDTO getExpensesById(int Id) throws BadRequestException;


     Expense addExpense(ExpenseDTO expenseDTO) throws BadRequestException;


     Expense updateExpense(int id, ExpenseDTO expenseDTO) throws BadRequestException;


     boolean deleteExpense(int id) throws BadRequestException;

     String getExpenseOwnerEmail(int expenseId);
}
