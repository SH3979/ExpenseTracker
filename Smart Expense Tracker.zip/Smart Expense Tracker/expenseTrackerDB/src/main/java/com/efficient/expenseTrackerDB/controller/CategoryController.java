package com.efficient.expenseTrackerDB.controller;

import com.efficient.expenseTrackerDB.DTO.CategoryDTO;
import com.efficient.expenseTrackerDB.entity.Category;
import com.efficient.expenseTrackerDB.entity.Expense;
import com.efficient.expenseTrackerDB.service.ICategoryService;
import org.apache.coyote.BadRequestException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/categories/db")
public class CategoryController {

    private static final Logger logger = LoggerFactory.getLogger(CategoryController.class);
    private final ICategoryService iCategoryService;

    public CategoryController(ICategoryService iCategoryService) {
        this.iCategoryService = iCategoryService;
    }

    @GetMapping("/fetch")
    public ResponseEntity<List<CategoryDTO>> getAllCategories(){
        logger.info("Inside the getAllCategories() method in Controller");
        List<CategoryDTO> categoryList = iCategoryService.getAllCategories();
        return ResponseEntity.ok(categoryList);
    }

    @GetMapping("/fetch/{id}")
    public ResponseEntity<CategoryDTO> getCategoryById(@PathVariable int id) throws BadRequestException {
        logger.info("Inside the getCategoryById() method in Controller");
        CategoryDTO categoryDTO = iCategoryService.getCategoryById(id);
        return ResponseEntity.ok(categoryDTO);
    }

    @PostMapping("/add")
    public ResponseEntity<CategoryDTO> addCategory(@RequestBody CategoryDTO categoryDTO) throws BadRequestException {
        logger.info("Inside the addCategory method in Controller");
        Category savedCategory = iCategoryService.addCategory(categoryDTO);
        logger.info("Category is successfully added! {}", savedCategory);
        return ResponseEntity.ok(new CategoryDTO(savedCategory));
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<CategoryDTO> updateCategory(@PathVariable int id, @RequestBody CategoryDTO categoryDTO ) throws BadRequestException {
        logger.info("Inside the updateCategory method in Controller");
        Category updatedCategory = iCategoryService.updateCategory(id, categoryDTO);
        logger.info("Category is successfully updated! {}", updatedCategory);
        return ResponseEntity.ok(new CategoryDTO(updatedCategory));
    }

    @DeleteMapping("/delete/{id}")
    public String deleteCategory(@PathVariable int id) throws BadRequestException {
        logger.info("Inside deleteUser() in Controller");
        boolean isSuccess = iCategoryService.deleteCategory(id);
        if(isSuccess){
            return "The category has been successfully deleted";
        }
        throw new BadRequestException("The category could not be deleted");
    }

}
